# @dmills-veeva/vault-vibe-design-system

Veeva Vault unified design system — 31 React components, design tokens, and a Tailwind config. Built from the Vault Figma UI kit and UIModules codebase.

## Install

`@dmills-veeva/vault-vibe-design-system` is published to GitHub Packages and restricted to Veeva org members.

### 1. Authenticate with GitHub Packages (one-time setup)

Create a GitHub Personal Access Token with `read:packages` scope:
[github.com/settings/tokens/new?scopes=read:packages](https://github.com/settings/tokens/new?scopes=read:packages)

Add the following to your project's `.npmrc` (or `~/.npmrc` for global setup):

```
@dmills-veeva:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=YOUR_TOKEN
```

Replace `YOUR_TOKEN` with the token you created. Do not commit `.npmrc` if it contains a token — use an environment variable instead:

```
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

Then set `NPM_TOKEN` in your shell profile or CI environment.

### 2. Install the package

```bash
npm install @dmills-veeva/vault-vibe-design-system
```

```json
{
  "dependencies": {
    "@dmills-veeva/vault-vibe-design-system": "^1.0.0"
  }
}
```

---

## Development setup (working on vault-ui itself)

```bash
cd packages/vault-ui
npm install
```

### Build

Compiles TypeScript to `dist/` (dual CJS + ESM with `.d.ts` declarations):

```bash
npm run build
```

Watch mode for iterative development:

```bash
npm run dev
```

### Tests

```bash
npm test               # run once
npm run test:watch     # watch mode
```

Tests use Jest + jsdom + `@testing-library/react`. Each component has a `.test.tsx` file covering rendering, variant classes, interaction handlers, and disabled/required states.

### Storybook

```bash
npm run storybook      # starts on http://localhost:6007
npm run build-storybook
```

Every component has a `.stories.tsx` file with Default and variant stories.

---

## Usage

### 1. Load fonts and styles

Add to your app's root CSS or entry file:

```css
/* Loads Roboto (Google Fonts CDN) + Font Awesome 6 (CDN) + all --vault-* CSS variables */
@import '@dmills-veeva/vault-vibe-design-system/tokens.css';

/* Tailwind base/components/utilities — only needed if your app uses Tailwind */
@import '@dmills-veeva/vault-vibe-design-system/tailwind.css';
```

Or in a JS/TS entry file:

```ts
import '@dmills-veeva/vault-vibe-design-system/tokens.css';
```

### 2. Add the Tailwind config (Tailwind projects only)

```js
// tailwind.config.js
const vaultConfig = require('@dmills-veeva/vault-vibe-design-system/tailwind.config');

module.exports = {
  content: [
    './src/**/*.{ts,tsx}',
    './node_modules/@dmills-veeva/vault-vibe-design-system/src/**/*.{ts,tsx}', // scan vault-ui for class names
  ],
  presets: [vaultConfig],
};
```

### 3. Import components

```tsx
import {
  Button, TextInput, Badge, Sidebar, GlobalHeader, WorkflowModal,
} from '@dmills-veeva/vault-vibe-design-system';
```

### 4. Import tokens (for CSS-in-JS, Tailwind `theme()`, or build-time use)

```ts
import { tokens } from '@dmills-veeva/vault-vibe-design-system';

tokens.colors.primary      // '#1453b8'
tokens.spacing[4]          // '16px'
tokens.shadows.modal       // '0 8px 10px 1px ...'
```

---

## Components

### Form controls
| Component | Notes |
|---|---|
| `Button` | `variant`: default / primary / ghost / danger · 24px height · 2px radius · 12px Roboto |
| `TextInput` | `required` → yellow `#ffffcc` bg · `error` → red border + message |
| `TextArea` | Same as TextInput, multiline |
| `Checkbox` | Custom-drawn · `required` → yellow bg |
| `Radio` | Custom-drawn · `required` → yellow bg |
| `Dropdown` | Select-style trigger |
| `Autocomplete` | Tag-based multi-select input |
| `SearchBox` | Search input with icon button and clear |

### Navigation & layout
| Component | Notes |
|---|---|
| `GlobalHeader` | 44px dark brand bar + 40px white tab bar · logo · search · avatar |
| `Sidebar` | UIModules facet pattern — collapsible groups, item counts, yellow active row + orange left border |
| `Tab` | Horizontal tabs with 3px orange active indicator |
| `Breadcrumb` | `›`-separated with link items and plain current item |
| `PageTitle` | 22px weight-400 heading with 2px orange bottom border |

### Data display
| Component | Notes |
|---|---|
| `DataGrid` | Sortable, selectable table · uppercase headers · hover + selected row colors |
| `LifecycleStage` | Chevron pipeline: done / current / upcoming |
| `Badge` | 9 tones: blue · bluelt · green · greenlt · red · yellow · orange · gray · graylt |
| `Tag` | Removable label chip |
| `Pill` | Blue filter chip (Autocomplete use) |
| `Avatar` | Photo when `src` provided · initials fallback in orange circle · sm/md/lg · online indicator |
| `Link` | Dark blue `#1453b8` · underline on hover · never orange |

### Overlays
| Component | Notes |
|---|---|
| `Modal` | Reusable shell: title · body · footer |
| `Dialog` | Confirm / cancel pattern built on Modal |
| `WorkflowModal` | Radio workflow picker · Pill participants · due date + note |
| `Menu` | Dropdown menu: sections, icons (FA), keyboard shortcuts |
| `Tooltip` | 4-position hover tooltip with arrow |
| `Hovercard` | Floating info card, sizes xs–lg |

### Feedback
| Component | Notes |
|---|---|
| `Alert` | Inline 38px strip · success / info / error / warning |
| `Banner` | Full-width with icon column · 4 tones |
| `Notification` | Floating toast · 360px · 4 tones |
| `Spinner` | SVG arc spinner · xs / sm / md / lg |

### Utility
| Component | Notes |
|---|---|
| `Pagination` | Page input + prev/next · optional total items count |

---

## Design tokens

All tokens are available as CSS custom properties after importing `tokens.css`, and as JS objects via the `tokens` export.

### Color semantic aliases

| Token | Value | Use |
|---|---|---|
| `--vault-primary` | `#1453b8` | Primary buttons, active borders |
| `--vault-primary-hover` | `#0c326e` | Button hover state |
| `--vault-accent` | `#f8972b` | Active tab underline, page title border, sidebar active |
| `--vault-danger` | `#ce1300` | Danger buttons, error states |
| `--vault-success` | `#539137` | Success badges, status |
| `--vault-link` | `#1453b8` | Link color (no orange hover) |
| `--vault-required` | `#ffffcc` | Required input background |
| `--vault-bg-row-hover` | `#eff4f6` | Table/list row hover |
| `--vault-bg-row-selected` | `#fff5ad` | Table/list row selected |
| `--vault-header` | `#061937` | Global header background |
| `--vault-border` | `#dadada` | Default border color |
| `--vault-muted` | `#646464` | Secondary text |

### Spacing (4px rhythm)

`--vault-sp-1` = 4px · `--vault-sp-2` = 8px · `--vault-sp-3` = 12px · `--vault-sp-4` = 16px · `--vault-sp-5` = 20px · `--vault-sp-6` = 24px · `--vault-sp-8` = 32px

### Typography

- **Font**: Roboto (loaded via Google Fonts CDN in `tokens.css`)
- **Body**: 12px / 1.43 line-height
- **Buttons/labels**: 12px medium
- **Table headers**: 10px bold uppercase, `letter-spacing: 0.06em`
- **Page title**: 22px weight-400

### Component dimensions

| | Value |
|---|---|
| Button height | 24px |
| Button radius | 2px |
| Input height | 28px |
| Input radius | 2px |
| Global header | 44px brand bar + 40px tab bar |
| Sidebar width | 220px (default) |

---

## Icons

Font Awesome 6 Free is loaded automatically from CDN via `tokens.css`. Use FA classes directly in JSX:

```tsx
<Button icon={<i className="fa-solid fa-plus" />}>Create Document</Button>
<i className="fa-solid fa-bell text-white" />
<i className="fa-solid fa-chevron-down text-vault-muted" />
```

Custom Vault SVG icons (workflow status, document types, folder icons, product logos) are available in `packages/vault-design-system-claude-uimodules/assets/`.

---

## Browser support

Modern evergreen browsers. Requires React ≥ 17. No IE11 support.
