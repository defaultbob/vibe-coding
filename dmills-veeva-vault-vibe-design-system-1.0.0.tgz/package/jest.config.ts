export default {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  setupFilesAfterFramework: ['./jest.setup.ts'],
  setupFilesAfterEnv: ['./jest.setup.ts'],
  moduleNameMapper: { '\\.(css|less|scss)$': '<rootDir>/__mocks__/fileMock.js' },
  transform: { '^.+\\.(ts|tsx)$': ['ts-jest', { tsconfig: { jsx: 'react-jsx' } }] },
  testMatch: ['**/*.test.ts', '**/*.test.tsx'],
};
