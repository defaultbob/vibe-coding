import type { Preview } from '@storybook/react';
import '../src/tokens.css';
import '../src/tailwind.css';

const preview: Preview = {
  parameters: {
    backgrounds: {
      default: 'page',
      values: [
        { name: 'page', value: '#f5f5f5' },
        { name: 'white', value: '#ffffff' },
      ],
    },
  },
};

export default preview;
