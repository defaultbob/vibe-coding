// Design tokens for @veeva/vault-ui
// Mirrors tailwind.config.js — use these in JS/TS contexts where Tailwind classes aren't available.

export const colors = {
  orange: {
    lightest: '#ffefd5',
    lighter: '#fcd19c',
    light: '#fab463',
    DEFAULT: '#f8972b',
    dark: '#f78b12',
    darker: '#d9780d',
    darkest: '#cc6600',
  },
  blue: {
    lightest: '#e3edfc',
    lighter: '#d1e1fa',
    light: '#acc8f6',
    DEFAULT: '#1453b8',
    dark: '#104293',
    darker: '#0c326e',
    darkest: '#092553',
  },
  red: {
    lightest: '#ffb3b3',
    lighter: '#ee7d75',
    light: '#de483a',
    DEFAULT: '#ce1300',
    dark: '#b71307',
    darker: '#a0140e',
    darkest: '#891515',
  },
  green: {
    lightest: '#e0f3e0',
    lighter: '#b1d2a7',
    light: '#82b16f',
    DEFAULT: '#539137',
    dark: '#427b2e',
    darker: '#316525',
    darkest: '#27571f',
  },
  yellow: {
    lightest: '#ffffcc',
    lighter: '#fff5ad',
    light: '#ffec8e',
    DEFAULT: '#ffe36f',
    dark: '#ffd950',
    darker: '#ffd031',
    darkest: '#e6c10b',
  },
  gray: {
    lightest: '#f8f8f8',
    lighter: '#f5f5f5',
    light: '#eeeeee',
    DEFAULT: '#dadada',
    dark: '#cccccc',
    darker: '#c0c0c0',
    darkest: '#b3b3b3',
  },
  // Semantic aliases
  primary: '#1453b8',
  primaryHover: '#0c326e',
  primaryActive: '#092553',
  accent: '#f8972b',
  danger: '#ce1300',
  success: '#539137',
  warning: '#ffe36f',
  link: '#1453b8',
  body: '#1d1d1d',
  muted: '#646464',
  placeholder: '#aaaaaa',
  disabled: '#aaaaaa',
  border: '#dadada',
  borderStrong: '#cccccc',
  bg: '#ffffff',
  bgPage: '#f5f5f5',
  bgAlt: '#f8f8f8',
  bgRowHover: '#eff4f6',
  bgRowSelected: '#fff5ad',
  required: '#ffffcc',
  header: '#061937',
  ink: '#1d1d1d',
  white: '#ffffff',
  black: '#1d1d1d',
} as const;

export const spacing = {
  0: '0px',
  0.5: '2px',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
  16: '64px',
} as const;

export const radius = {
  none: '0',
  xs: '2px',
  sm: '3px',
  DEFAULT: '4px',
  lg: '6px',
  full: '9999px',
} as const;

export const shadows = {
  dropdown: '0 3px 6px rgba(0,0,0,.23)',
  modal: '0 8px 10px 1px rgba(0,0,0,.18), 0 3px 14px 2px rgba(0,0,0,.16), 0 5px 5px -3px rgba(0,0,0,.24)',
  panel: '0 1px 3px rgba(0,0,0,.12)',
  overlay: '0 2px 4px -1px rgba(0,0,0,.2), 0 1px 10px 0 rgba(0,0,0,.12), 0 4px 5px 0 rgba(0,0,0,.14)',
} as const;

export const typography = {
  fontSans: ['Roboto', 'Arial', 'Helvetica', 'sans-serif'],
  fontMono: ['Roboto Mono', 'Menlo', 'Consolas', 'monospace'],
  sizes: {
    micro: { fontSize: '9px', lineHeight: '12px' },
    label: { fontSize: '10px', lineHeight: '14px' },
    xs: { fontSize: '11px', lineHeight: '15px' },
    sm: { fontSize: '12px', lineHeight: '17px' },
    base: { fontSize: '14px', lineHeight: '20px' },
    lg: { fontSize: '16px', lineHeight: '22px' },
    xl: { fontSize: '18px', lineHeight: '24px' },
    '2xl': { fontSize: '22px', lineHeight: '28px' },
    '3xl': { fontSize: '32px', lineHeight: '38px' },
  },
} as const;

export const chrome = {
  headerHeight: '44px',
  tabBarHeight: '40px',
  sidebarWidth: '220px',
  btnHeight: '24px',
  btnRadius: '2px',
  inputRadius: '2px',
} as const;
