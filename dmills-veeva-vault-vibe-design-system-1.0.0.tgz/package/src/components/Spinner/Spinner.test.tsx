import { render, screen } from '@testing-library/react';
import { Spinner } from './Spinner';

describe('Spinner', () => {
  it('renders without crashing', () => {
    render(<Spinner />);
    expect(screen.getByRole('status')).toBeInTheDocument();
  });

  it('has aria-label=Loading', () => {
    render(<Spinner />);
    expect(screen.getByLabelText('Loading')).toBeInTheDocument();
  });

  it('applies animate-spin class', () => {
    render(<Spinner />);
    expect(screen.getByRole('status')).toHaveClass('animate-spin');
  });

  it('renders xs size (12px)', () => {
    render(<Spinner size="xs" />);
    expect(screen.getByRole('status')).toHaveAttribute('width', '12');
  });

  it('renders sm size (16px)', () => {
    render(<Spinner size="sm" />);
    expect(screen.getByRole('status')).toHaveAttribute('width', '16');
  });

  it('renders md size (20px)', () => {
    render(<Spinner size="md" />);
    expect(screen.getByRole('status')).toHaveAttribute('width', '20');
  });

  it('renders lg size (28px)', () => {
    render(<Spinner size="lg" />);
    expect(screen.getByRole('status')).toHaveAttribute('width', '28');
  });

  it('uses custom color', () => {
    const { container } = render(<Spinner color="#ce1300" />);
    const circles = container.querySelectorAll('circle');
    expect(circles[0]).toHaveAttribute('stroke', '#ce1300');
  });
});
