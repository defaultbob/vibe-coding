import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Spinner } from './Spinner';

const meta: Meta<typeof Spinner> = {
  title: 'Components/Spinner',
  component: Spinner,
};
export default meta;
type Story = StoryObj<typeof Spinner>;

export const Default: Story = { args: { size: 'md' } };
export const ExtraSmall: Story = { args: { size: 'xs' } };
export const Small: Story = { args: { size: 'sm' } };
export const Large: Story = { args: { size: 'lg' } };
export const OrangeColor: Story = { args: { size: 'md', color: '#f8972b' } };
export const WhiteOnDark: StoryObj = {
  render: () => (
    <div className="bg-vault-primary p-4 inline-flex rounded">
      <Spinner size="md" color="#ffffff" />
    </div>
  ),
};
export const AllSizes: StoryObj = {
  render: () => (
    <div className="flex items-center gap-4">
      <Spinner size="xs" />
      <Spinner size="sm" />
      <Spinner size="md" />
      <Spinner size="lg" />
    </div>
  ),
};
