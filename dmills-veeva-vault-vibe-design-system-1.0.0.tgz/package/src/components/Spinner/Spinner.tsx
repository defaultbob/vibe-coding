import React from 'react';
import { cn } from '../../utils/cn';

export type SpinnerSize = 'xs' | 'sm' | 'md' | 'lg';

export interface SpinnerProps {
  size?: SpinnerSize;
  color?: string;
  className?: string;
}

const sizeMap: Record<SpinnerSize, number> = {
  xs: 12,
  sm: 16,
  md: 20,
  lg: 28,
};

export const Spinner: React.FC<SpinnerProps> = ({
  size = 'md',
  color = '#1453b8',
  className,
}) => {
  const px = sizeMap[size];
  const r = (px - 4) / 2;
  const cx = px / 2;
  const cy = px / 2;
  const circumference = 2 * Math.PI * r;
  const dashArray = circumference;
  const dashOffset = circumference * 0.25; // 75% arc

  return (
    <svg
      width={px}
      height={px}
      viewBox={`0 0 ${px} ${px}`}
      className={cn('animate-spin', className)}
      aria-label="Loading"
      role="status"
      style={{ flexShrink: 0 }}
    >
      {/* Track */}
      <circle
        cx={cx}
        cy={cy}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth={2}
        opacity={0.2}
      />
      {/* Arc */}
      <circle
        cx={cx}
        cy={cy}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        strokeDasharray={`${dashArray * 0.75} ${dashArray * 0.25}`}
        strokeDashoffset={0}
        style={{ transformOrigin: `${cx}px ${cy}px` }}
      />
    </svg>
  );
};

Spinner.displayName = 'Spinner';
