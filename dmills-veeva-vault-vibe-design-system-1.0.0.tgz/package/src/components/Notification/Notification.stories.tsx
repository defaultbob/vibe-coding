import type { Meta, StoryObj } from '@storybook/react';
import { Notification } from './Notification';

const meta: Meta<typeof Notification> = {
  title: 'Components/Notification',
  component: Notification,
};
export default meta;
type Story = StoryObj<typeof Notification>;

export const Success: Story = {
  args: {
    tone: 'success',
    title: 'Document Saved',
    children: '"Protocol v1.0" has been saved successfully.',
    position: 'top-right',
    onClose: () => {},
  },
};

export const Error: Story = {
  args: {
    tone: 'error',
    title: 'Upload Failed',
    children: 'The file could not be uploaded. Please try again.',
    position: 'top-right',
    onClose: () => {},
  },
};

export const Warning: Story = {
  args: {
    tone: 'warning',
    title: 'Unsaved Changes',
    children: 'You have unsaved changes. They will be lost if you navigate away.',
    position: 'top-right',
    onClose: () => {},
  },
};

export const Info: Story = {
  args: {
    tone: 'info',
    title: 'Workflow Started',
    children: 'The approval workflow has been started. Reviewers have been notified.',
    position: 'top-right',
    onClose: () => {},
  },
};
