import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Notification } from './Notification';

describe('Notification', () => {
  it('renders children', () => {
    render(<Notification tone="success">Document saved.</Notification>);
    expect(screen.getByText('Document saved.')).toBeInTheDocument();
  });

  it('renders title', () => {
    render(<Notification tone="info" title="Update Available">New version ready.</Notification>);
    expect(screen.getByText('Update Available')).toBeInTheDocument();
  });

  it('has role=alert', () => {
    render(<Notification tone="error">Error occurred.</Notification>);
    expect(screen.getByRole('alert')).toBeInTheDocument();
  });

  it('shows close button when onClose provided', () => {
    render(<Notification tone="success" onClose={() => {}}>Saved.</Notification>);
    expect(screen.getByRole('button', { name: 'Dismiss notification' })).toBeInTheDocument();
  });

  it('calls onClose when dismiss clicked', async () => {
    const fn = jest.fn();
    render(<Notification tone="warning" onClose={fn}>Warning msg.</Notification>);
    await userEvent.click(screen.getByRole('button', { name: 'Dismiss notification' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('applies success border class', () => {
    render(<Notification tone="success">OK</Notification>);
    expect(screen.getByRole('alert')).toHaveClass('border-vault-green-light');
  });

  it('applies error border class', () => {
    render(<Notification tone="error">Error</Notification>);
    expect(screen.getByRole('alert')).toHaveClass('border-vault-red-light');
  });
});
