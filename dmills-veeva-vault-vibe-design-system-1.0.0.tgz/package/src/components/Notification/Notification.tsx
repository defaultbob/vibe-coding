import React from 'react';
import { cn } from '../../utils/cn';

export type NotificationTone = 'info' | 'success' | 'warning' | 'error';
export type NotificationPosition =
  | 'top-right'
  | 'top-left'
  | 'bottom-right'
  | 'bottom-left'
  | 'top-center';

export interface NotificationProps {
  tone: NotificationTone;
  title?: string;
  onClose?: () => void;
  icon?: string;
  position?: NotificationPosition;
  children: React.ReactNode;
  className?: string;
}

const toneConfig: Record<
  NotificationTone,
  { bg: string; iconBg: string; icon: string; iconColor: string }
> = {
  info: {
    bg: 'bg-vault-bg border border-vault-blue-light',
    iconBg: 'bg-vault-primary',
    icon: 'fa-solid fa-circle-info',
    iconColor: 'text-white',
  },
  success: {
    bg: 'bg-vault-bg border border-vault-green-light',
    iconBg: 'bg-vault-success',
    icon: 'fa-solid fa-circle-check',
    iconColor: 'text-white',
  },
  warning: {
    bg: 'bg-vault-bg border border-vault-yellow-darker',
    iconBg: 'bg-vault-accent',
    icon: 'fa-solid fa-triangle-exclamation',
    iconColor: 'text-white',
  },
  error: {
    bg: 'bg-vault-bg border border-vault-red-light',
    iconBg: 'bg-vault-danger',
    icon: 'fa-solid fa-circle-exclamation',
    iconColor: 'text-white',
  },
};

const positionStyles: Record<NotificationPosition, string> = {
  'top-right': 'fixed top-4 right-4',
  'top-left': 'fixed top-4 left-4',
  'bottom-right': 'fixed bottom-4 right-4',
  'bottom-left': 'fixed bottom-4 left-4',
  'top-center': 'fixed top-4 left-1/2 -translate-x-1/2',
};

export const Notification: React.FC<NotificationProps> = ({
  tone,
  title,
  onClose,
  icon,
  position = 'top-right',
  children,
  className,
}) => {
  const config = toneConfig[tone];
  const iconClass = icon ?? config.icon;

  return (
    <div
      role="alert"
      aria-live="polite"
      className={cn(
        'w-[360px] flex rounded-[2px] shadow-modal overflow-hidden z-[9999]',
        config.bg,
        positionStyles[position],
        className
      )}
    >
      {/* Colored icon strip */}
      <div
        className={cn(
          'flex items-start justify-center w-10 flex-shrink-0 pt-3',
          config.iconBg
        )}
      >
        <i className={cn(iconClass, config.iconColor, 'text-sm')} aria-hidden="true" />
      </div>

      {/* Body */}
      <div className="flex-1 px-3 py-2.5">
        {title && <p className="text-sm font-bold text-vault-ink mb-0.5">{title}</p>}
        <div className="text-sm text-vault-ink">{children}</div>
      </div>

      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Dismiss notification"
          className="flex-shrink-0 mr-2 mt-2 text-vault-muted hover:text-vault-ink text-base leading-none"
        >
          ×
        </button>
      )}
    </div>
  );
};

Notification.displayName = 'Notification';
