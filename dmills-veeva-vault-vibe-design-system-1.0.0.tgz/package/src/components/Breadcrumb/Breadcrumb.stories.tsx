import type { Meta, StoryObj } from '@storybook/react';
import { Breadcrumb } from './Breadcrumb';

const meta: Meta<typeof Breadcrumb> = {
  title: 'Components/Breadcrumb',
  component: Breadcrumb,
};
export default meta;
type Story = StoryObj<typeof Breadcrumb>;

export const Default: Story = {
  args: {
    items: [
      { label: 'Vault', href: '/' },
      { label: 'Documents', href: '/documents' },
      { label: 'Clinical', href: '/documents/clinical' },
      { label: 'Study Protocol v2.1' },
    ],
  },
};

export const TwoLevel: Story = {
  args: {
    items: [
      { label: 'Documents', href: '/documents' },
      { label: 'Informed Consent Form' },
    ],
  },
};

export const SingleItem: Story = {
  args: { items: [{ label: 'Documents' }] },
};
