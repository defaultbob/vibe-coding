import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Breadcrumb } from './Breadcrumb';

const items = [
  { label: 'Home', href: '/' },
  { label: 'Documents', href: '/docs' },
  { label: 'Study Protocol v2.1' },
];

describe('Breadcrumb', () => {
  it('renders all items', () => {
    render(<Breadcrumb items={items} />);
    expect(screen.getByText('Home')).toBeInTheDocument();
    expect(screen.getByText('Documents')).toBeInTheDocument();
    expect(screen.getByText('Study Protocol v2.1')).toBeInTheDocument();
  });

  it('last item has aria-current=page', () => {
    render(<Breadcrumb items={items} />);
    expect(screen.getByText('Study Protocol v2.1')).toHaveAttribute('aria-current', 'page');
  });

  it('non-last items are links', () => {
    render(<Breadcrumb items={items} />);
    const homeLink = screen.getByRole('link', { name: 'Home' });
    expect(homeLink).toHaveAttribute('href', '/');
  });

  it('calls onClick handler', async () => {
    const fn = jest.fn();
    render(<Breadcrumb items={[{ label: 'Home', onClick: fn }, { label: 'Current' }]} />);
    await userEvent.click(screen.getByRole('button', { name: 'Home' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('renders separators between items', () => {
    render(<Breadcrumb items={items} />);
    const separators = screen.getAllByText('›');
    expect(separators).toHaveLength(items.length - 1);
  });
});
