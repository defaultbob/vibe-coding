import React from 'react';
import { cn } from '../../utils/cn';

export interface BreadcrumbItem {
  label: string;
  href?: string;
  onClick?: () => void;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
  className?: string;
}

export const Breadcrumb = React.forwardRef<HTMLElement, BreadcrumbProps>(
  ({ items, className }, ref) => {
    return (
      <nav ref={ref} aria-label="Breadcrumb" className={cn('flex items-center', className)}>
        <ol className="flex items-center gap-1 text-sm text-vault-muted list-none m-0 p-0">
          {items.map((item, i) => {
            const isLast = i === items.length - 1;
            return (
              <li key={i} className="flex items-center gap-1">
                {i > 0 && (
                  <span aria-hidden="true" className="text-vault-muted select-none">
                    ›
                  </span>
                )}
                {isLast ? (
                  <span className="text-vault-ink" aria-current="page">
                    {item.label}
                  </span>
                ) : item.href ? (
                  <a href={item.href} className="text-vault-link hover:underline">
                    {item.label}
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={item.onClick}
                    className="text-vault-link hover:underline bg-transparent border-0 p-0 cursor-pointer font-inherit text-inherit"
                  >
                    {item.label}
                  </button>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
    );
  }
);

Breadcrumb.displayName = 'Breadcrumb';
