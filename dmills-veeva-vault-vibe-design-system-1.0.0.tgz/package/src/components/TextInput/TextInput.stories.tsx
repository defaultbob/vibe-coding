import type { Meta, StoryObj } from '@storybook/react';
import { TextInput } from './TextInput';

const meta: Meta<typeof TextInput> = {
  title: 'Components/TextInput',
  component: TextInput,
};
export default meta;
type Story = StoryObj<typeof TextInput>;

export const Default: Story = { args: { label: 'Document Name', placeholder: 'Enter document name' } };
export const Required: Story = { args: { label: 'Document Number', required: true } };
export const WithError: Story = { args: { label: 'Document Number', error: 'This field is required.', value: '' } };
export const WithHelperText: Story = { args: { label: 'Version Label', helperText: 'e.g. v1.0, 2.3-draft', placeholder: 'v1.0' } };
export const Disabled: Story = { args: { label: 'Created By', value: 'David Mills', disabled: true } };
export const Password: Story = { args: { label: 'Password', type: 'password', placeholder: '••••••••' } };
