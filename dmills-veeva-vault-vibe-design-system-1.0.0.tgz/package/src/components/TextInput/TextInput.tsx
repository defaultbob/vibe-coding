import React, { useId } from 'react';
import { cn } from '../../utils/cn';

export interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  helperText?: string;
  error?: string;
}

export const TextInput = React.forwardRef<HTMLInputElement, TextInputProps>(
  ({ label, helperText, error, required, disabled, className, type = 'text', id: externalId, ...props }, ref) => {
    const generatedId = useId();
    const id = externalId ?? generatedId;

    return (
      <div className="flex flex-col gap-0.5">
        {label && (
          <label htmlFor={id} className="text-xs font-bold text-vault-ink">
            {label}
            {required && <span className="text-vault-danger ml-0.5">*</span>}
          </label>
        )}
        <input
          ref={ref}
          id={id}
          type={type}
          required={required}
          disabled={disabled}
          className={cn(
            'h-7 rounded-[2px] border text-sm px-2 focus:outline-none focus:border-vault-primary transition-colors',
            required
              ? 'bg-vault-required border-vault-primary'
              : error
              ? 'bg-red-50 border-vault-danger'
              : 'bg-vault-bg border-vault-border',
            disabled && 'bg-vault-bg-alt opacity-60 cursor-not-allowed',
            className
          )}
          {...props}
        />
        {error && (
          <p className="text-label text-vault-danger">{error}</p>
        )}
        {helperText && !error && (
          <p className="text-label text-vault-muted">{helperText}</p>
        )}
      </div>
    );
  }
);

TextInput.displayName = 'TextInput';
