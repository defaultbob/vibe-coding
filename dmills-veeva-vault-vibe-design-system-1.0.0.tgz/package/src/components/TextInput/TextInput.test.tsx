import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TextInput } from './TextInput';

describe('TextInput', () => {
  it('renders without crashing', () => {
    render(<TextInput />);
    expect(screen.getByRole('textbox')).toBeInTheDocument();
  });

  it('renders label', () => {
    render(<TextInput label="Document Name" />);
    expect(screen.getByText('Document Name')).toBeInTheDocument();
  });

  it('required prop applies yellow bg class', () => {
    render(<TextInput required />);
    expect(screen.getByRole('textbox')).toHaveClass('bg-vault-required');
  });

  it('required prop applies primary border', () => {
    render(<TextInput required />);
    expect(screen.getByRole('textbox')).toHaveClass('border-vault-primary');
  });

  it('error shows error message', () => {
    render(<TextInput error="This field is required" />);
    expect(screen.getByText('This field is required')).toBeInTheDocument();
  });

  it('error applies danger border', () => {
    render(<TextInput error="Error" />);
    expect(screen.getByRole('textbox')).toHaveClass('border-vault-danger');
  });

  it('helperText shown when no error', () => {
    render(<TextInput helperText="Enter the full document name" />);
    expect(screen.getByText('Enter the full document name')).toBeInTheDocument();
  });

  it('disabled input has disabled attribute', () => {
    render(<TextInput disabled />);
    expect(screen.getByRole('textbox')).toBeDisabled();
  });

  it('calls onChange when text entered', async () => {
    const fn = jest.fn();
    render(<TextInput onChange={fn} />);
    await userEvent.type(screen.getByRole('textbox'), 'Protocol v1');
    expect(fn).toHaveBeenCalled();
  });

  it('required asterisk shows in label', () => {
    render(<TextInput label="Name" required />);
    expect(screen.getByText('*')).toBeInTheDocument();
  });

  it('has correct height class', () => {
    render(<TextInput />);
    expect(screen.getByRole('textbox')).toHaveClass('h-7');
  });
});
