import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Menu } from './Menu';

const sections = [
  {
    items: [
      { label: 'Edit', icon: 'fa-solid fa-pen', onClick: jest.fn() },
      { label: 'Duplicate', icon: 'fa-solid fa-copy', onClick: jest.fn() },
    ],
  },
  {
    items: [
      { label: 'Delete', icon: 'fa-solid fa-trash', onClick: jest.fn() },
    ],
  },
];

describe('Menu', () => {
  it('renders all menu items', () => {
    render(<Menu sections={sections} />);
    expect(screen.getByText('Edit')).toBeInTheDocument();
    expect(screen.getByText('Duplicate')).toBeInTheDocument();
    expect(screen.getByText('Delete')).toBeInTheDocument();
  });

  it('calls onClick when item clicked', async () => {
    const fn = jest.fn();
    render(<Menu sections={[{ items: [{ label: 'Save', onClick: fn }] }]} />);
    await userEvent.click(screen.getByRole('menuitem', { name: 'Save' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not call onClick for disabled items', async () => {
    const fn = jest.fn();
    render(<Menu sections={[{ items: [{ label: 'Delete', disabled: true, onClick: fn }] }]} />);
    await userEvent.click(screen.getByRole('menuitem', { name: 'Delete' }));
    expect(fn).not.toHaveBeenCalled();
  });

  it('renders section separator between sections', () => {
    render(<Menu sections={sections} />);
    expect(screen.getByRole('separator')).toBeInTheDocument();
  });

  it('renders section header', () => {
    render(<Menu sections={[{ header: 'Actions', items: [{ label: 'Go' }] }]} />);
    expect(screen.getByText('Actions')).toBeInTheDocument();
  });

  it('renders shortcut text', () => {
    render(<Menu sections={[{ items: [{ label: 'Copy', shortcut: '⌘C' }] }]} />);
    expect(screen.getByText('⌘C')).toBeInTheDocument();
  });
});
