import React from 'react';
import { cn } from '../../utils/cn';

export interface MenuItem {
  label: React.ReactNode;
  icon?: string;
  shortcut?: string;
  disabled?: boolean;
  onClick?: () => void;
}

export interface MenuSection {
  header?: string;
  items: MenuItem[];
}

export interface MenuProps {
  sections: MenuSection[];
  width?: number;
  className?: string;
}

export const Menu = React.forwardRef<HTMLDivElement, MenuProps>(
  ({ sections, width = 200, className }, ref) => {
    return (
      <div
        ref={ref}
        role="menu"
        style={{ width }}
        className={cn(
          'bg-vault-bg border border-vault-border rounded-[2px] shadow-dropdown py-1 overflow-hidden',
          className
        )}
      >
        {sections.map((section, si) => (
          <div key={si}>
            {si > 0 && <div className="border-t border-vault-border my-1" role="separator" />}
            {section.header && (
              <div className="px-3 py-1 text-label font-bold uppercase tracking-wider text-vault-muted">
                {section.header}
              </div>
            )}
            {section.items.map((item, ii) => (
              <button
                key={ii}
                type="button"
                role="menuitem"
                disabled={item.disabled}
                onClick={item.disabled ? undefined : item.onClick}
                className={cn(
                  'w-full flex items-center gap-0 px-3 h-7 text-sm text-vault-ink text-left cursor-pointer border-0 bg-transparent transition-colors',
                  item.disabled
                    ? 'text-vault-disabled cursor-not-allowed opacity-60'
                    : 'hover:bg-vault-bg-row-hover'
                )}
              >
                {item.icon && (
                  <span className="w-5 mr-2 text-vault-muted flex-shrink-0">
                    <i className={cn(item.icon, 'text-sm')} aria-hidden="true" />
                  </span>
                )}
                <span className="flex-1">{item.label}</span>
                {item.shortcut && (
                  <span className="text-label text-vault-muted ml-4">{item.shortcut}</span>
                )}
              </button>
            ))}
          </div>
        ))}
      </div>
    );
  }
);

Menu.displayName = 'Menu';
