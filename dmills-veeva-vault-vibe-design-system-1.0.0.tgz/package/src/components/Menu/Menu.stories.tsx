import type { Meta, StoryObj } from '@storybook/react';
import { Menu } from './Menu';

const meta: Meta<typeof Menu> = {
  title: 'Components/Menu',
  component: Menu,
};
export default meta;
type Story = StoryObj<typeof Menu>;

export const Default: Story = {
  args: {
    sections: [
      {
        items: [
          { label: 'View Document', icon: 'fa-solid fa-eye' },
          { label: 'Edit Document', icon: 'fa-solid fa-pen' },
          { label: 'Download', icon: 'fa-solid fa-download' },
        ],
      },
      {
        items: [
          { label: 'Move to Binder', icon: 'fa-solid fa-folder-open' },
          { label: 'Copy Link', icon: 'fa-solid fa-link', shortcut: '⌘L' },
        ],
      },
      {
        items: [
          { label: 'Delete', icon: 'fa-solid fa-trash', disabled: false },
        ],
      },
    ],
  },
};

export const WithSectionHeader: Story = {
  args: {
    sections: [
      {
        header: 'Lifecycle',
        items: [
          { label: 'Submit for Review' },
          { label: 'Approve' },
          { label: 'Reject', disabled: true },
        ],
      },
      {
        header: 'Manage',
        items: [
          { label: 'Assign Owner' },
          { label: 'Set Expiry Date' },
        ],
      },
    ],
  },
};
