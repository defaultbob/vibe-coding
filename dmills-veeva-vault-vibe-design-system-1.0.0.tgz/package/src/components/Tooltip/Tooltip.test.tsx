import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Tooltip } from './Tooltip';

describe('Tooltip', () => {
  it('renders trigger children', () => {
    render(<Tooltip content="Helpful hint"><button>Hover me</button></Tooltip>);
    expect(screen.getByText('Hover me')).toBeInTheDocument();
  });

  it('tooltip not visible initially', () => {
    render(<Tooltip content="Hint"><button>Trigger</button></Tooltip>);
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('shows tooltip on hover', async () => {
    render(<Tooltip content="Helpful hint"><button>Hover me</button></Tooltip>);
    await userEvent.hover(screen.getByText('Hover me'));
    expect(screen.getByRole('tooltip')).toBeInTheDocument();
    expect(screen.getByRole('tooltip')).toHaveTextContent('Helpful hint');
  });

  it('hides tooltip after mouse leave', async () => {
    render(<Tooltip content="Hint"><button>Trigger</button></Tooltip>);
    await userEvent.hover(screen.getByText('Trigger'));
    await userEvent.unhover(screen.getByText('Trigger'));
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('shows tooltip on focus', async () => {
    render(<Tooltip content="Keyboard hint"><button>Focus me</button></Tooltip>);
    screen.getByText('Focus me').focus();
    expect(screen.getByRole('tooltip')).toBeInTheDocument();
  });

  it('applies above position style', async () => {
    render(<Tooltip content="Above" position="above"><button>T</button></Tooltip>);
    await userEvent.hover(screen.getByText('T'));
    expect(screen.getByRole('tooltip')).toHaveClass('bottom-full');
  });

  it('applies below position style', async () => {
    render(<Tooltip content="Below" position="below"><button>T</button></Tooltip>);
    await userEvent.hover(screen.getByText('T'));
    expect(screen.getByRole('tooltip')).toHaveClass('top-full');
  });
});
