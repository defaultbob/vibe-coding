import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Tooltip } from './Tooltip';
import { Button } from '../Button/Button';

const meta: Meta<typeof Tooltip> = {
  title: 'Components/Tooltip',
  component: Tooltip,
};
export default meta;

export const Above: StoryObj = {
  render: () => (
    <div className="flex items-center justify-center h-32">
      <Tooltip content="Submit document for review" position="above">
        <Button variant="primary">Submit</Button>
      </Tooltip>
    </div>
  ),
};

export const Below: StoryObj = {
  render: () => (
    <div className="flex items-center justify-center h-32">
      <Tooltip content="This action cannot be undone" position="below">
        <Button variant="danger">Delete</Button>
      </Tooltip>
    </div>
  ),
};

export const Left: StoryObj = {
  render: () => (
    <div className="flex items-center justify-center h-32">
      <Tooltip content="Opens document properties panel" position="left">
        <Button>Properties</Button>
      </Tooltip>
    </div>
  ),
};

export const Right: StoryObj = {
  render: () => (
    <div className="flex items-center justify-center h-32">
      <Tooltip content="Download the document as PDF" position="right">
        <Button icon={<i className="fa-solid fa-download" />}>Download</Button>
      </Tooltip>
    </div>
  ),
};

export const LongContent: StoryObj = {
  render: () => (
    <div className="flex items-center justify-center h-32">
      <Tooltip
        content="This document requires electronic signature from the Principal Investigator before it can be submitted."
        position="above"
      >
        <Button variant="ghost">Why can't I submit?</Button>
      </Tooltip>
    </div>
  ),
};
