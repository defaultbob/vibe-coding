import React, { useState } from 'react';
import { cn } from '../../utils/cn';

export type TooltipPosition = 'above' | 'below' | 'left' | 'right';

export interface TooltipProps {
  content: React.ReactNode;
  position?: TooltipPosition;
  children: React.ReactNode;
  className?: string;
}

const positionStyles: Record<
  TooltipPosition,
  { tooltip: string; arrow: string }
> = {
  above: {
    tooltip: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    arrow:
      'absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-[#414141]',
  },
  below: {
    tooltip: 'top-full left-1/2 -translate-x-1/2 mt-2',
    arrow:
      'absolute bottom-full left-1/2 -translate-x-1/2 border-4 border-transparent border-b-[#414141]',
  },
  left: {
    tooltip: 'right-full top-1/2 -translate-y-1/2 mr-2',
    arrow:
      'absolute left-full top-1/2 -translate-y-1/2 border-4 border-transparent border-l-[#414141]',
  },
  right: {
    tooltip: 'left-full top-1/2 -translate-y-1/2 ml-2',
    arrow:
      'absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-[#414141]',
  },
};

export const Tooltip: React.FC<TooltipProps> = ({
  content,
  position = 'above',
  children,
  className,
}) => {
  const [visible, setVisible] = useState(false);
  const pos = positionStyles[position];

  return (
    <span
      className={cn('relative inline-flex', className)}
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {children}
      {visible && (
        <span
          role="tooltip"
          className={cn(
            'absolute z-[2000] pointer-events-none',
            'bg-[#414141] text-white text-xs leading-tight rounded px-2 py-1.5 whitespace-nowrap max-w-[260px]',
            pos.tooltip
          )}
        >
          {content}
          <span className={pos.arrow} />
        </span>
      )}
    </span>
  );
};

Tooltip.displayName = 'Tooltip';
