export { Tab, TabList, VerticalTab, VerticalTabList } from './Tab';
export type { TabProps, TabListProps, VerticalTabProps, VerticalTabListProps } from './Tab';
