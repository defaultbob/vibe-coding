import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Tab, TabList, VerticalTab, VerticalTabList } from './Tab';

describe('Tab', () => {
  it('renders label', () => {
    render(<Tab label="Documents" />);
    expect(screen.getByText('Documents')).toBeInTheDocument();
  });

  it('active tab has aria-selected=true', () => {
    render(<Tab label="Documents" active />);
    expect(screen.getByRole('tab')).toHaveAttribute('aria-selected', 'true');
  });

  it('inactive tab has aria-selected=false', () => {
    render(<Tab label="Documents" />);
    expect(screen.getByRole('tab')).toHaveAttribute('aria-selected', 'false');
  });

  it('calls onClick when clicked', async () => {
    const fn = jest.fn();
    render(<Tab label="Documents" onClick={fn} />);
    await userEvent.click(screen.getByRole('tab'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not call onClick when disabled', async () => {
    const fn = jest.fn();
    render(<Tab label="Documents" disabled onClick={fn} />);
    await userEvent.click(screen.getByRole('tab'));
    expect(fn).not.toHaveBeenCalled();
  });

  it('active tab has font-bold class', () => {
    render(<Tab label="Documents" active />);
    expect(screen.getByRole('tab')).toHaveClass('font-bold');
  });

  it('renders count badge', () => {
    render(<Tab label="Documents" count={12} />);
    expect(screen.getByText('12')).toBeInTheDocument();
  });
});

describe('TabList', () => {
  it('renders with role=tablist', () => {
    render(
      <TabList>
        <Tab label="Tab 1" />
        <Tab label="Tab 2" />
      </TabList>
    );
    expect(screen.getByRole('tablist')).toBeInTheDocument();
  });
});

describe('VerticalTab', () => {
  it('renders label', () => {
    render(<VerticalTab label="Properties" />);
    expect(screen.getByText('Properties')).toBeInTheDocument();
  });

  it('active tab has border-vault-accent class', () => {
    render(<VerticalTab label="Properties" active />);
    expect(screen.getByRole('tab')).toHaveClass('border-vault-accent');
  });

  it('calls onClick', async () => {
    const fn = jest.fn();
    render(<VerticalTab label="Properties" onClick={fn} />);
    await userEvent.click(screen.getByRole('tab'));
    expect(fn).toHaveBeenCalledTimes(1);
  });
});
