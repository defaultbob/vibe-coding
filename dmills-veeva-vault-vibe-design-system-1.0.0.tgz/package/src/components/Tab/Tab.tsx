import React from 'react';
import { cn } from '../../utils/cn';

// Horizontal Tab
export interface TabProps {
  label: string;
  active?: boolean;
  count?: number;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export const Tab: React.FC<TabProps> = ({ label, active, count, onClick, disabled, className }) => {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'relative px-3.5 py-2 text-sm cursor-pointer border-0 bg-transparent transition-colors select-none whitespace-nowrap',
        active
          ? 'text-vault-ink font-bold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[3px] after:bg-vault-accent after:content-[\'\']'
          : 'text-vault-muted hover:text-vault-ink',
        disabled && 'opacity-50 cursor-not-allowed pointer-events-none',
        className
      )}
    >
      <span className="inline-flex items-center gap-1.5">
        {label}
        {count !== undefined && (
          <span
            className={cn(
              'inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full text-label font-bold',
              active ? 'bg-vault-accent text-white' : 'bg-vault-gray-light text-vault-muted'
            )}
          >
            {count}
          </span>
        )}
      </span>
    </button>
  );
};

Tab.displayName = 'Tab';

// Tab list container
export interface TabListProps {
  children: React.ReactNode;
  className?: string;
}

export const TabList: React.FC<TabListProps> = ({ children, className }) => {
  return (
    <div
      role="tablist"
      className={cn(
        'flex items-center border-b border-vault-border overflow-x-auto',
        className
      )}
    >
      {children}
    </div>
  );
};

TabList.displayName = 'TabList';

// Vertical Tab
export interface VerticalTabProps {
  label: string;
  active?: boolean;
  count?: number;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export const VerticalTab: React.FC<VerticalTabProps> = ({
  label,
  active,
  count,
  onClick,
  disabled,
  className,
}) => {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'relative w-full flex items-center justify-between px-3.5 py-2 text-sm cursor-pointer border-0 bg-transparent transition-colors border-l-[3px]',
        active
          ? 'text-vault-ink font-bold border-vault-accent bg-vault-bg-row-hover'
          : 'text-vault-muted border-transparent hover:text-vault-ink hover:bg-vault-bg-row-hover',
        disabled && 'opacity-50 cursor-not-allowed pointer-events-none',
        className
      )}
    >
      <span>{label}</span>
      {count !== undefined && (
        <span className="text-label text-vault-muted">{count}</span>
      )}
    </button>
  );
};

VerticalTab.displayName = 'VerticalTab';

export interface VerticalTabListProps {
  children: React.ReactNode;
  className?: string;
}

export const VerticalTabList: React.FC<VerticalTabListProps> = ({ children, className }) => {
  return (
    <div role="tablist" aria-orientation="vertical" className={cn('flex flex-col', className)}>
      {children}
    </div>
  );
};
