import type { Meta, StoryObj } from '@storybook/react';
import React, { useState } from 'react';
import { Tab, TabList, VerticalTab, VerticalTabList } from './Tab';

const meta: Meta<typeof Tab> = {
  title: 'Components/Tab',
  component: Tab,
};
export default meta;

export const HorizontalTabs: StoryObj = {
  render: () => {
    const [active, setActive] = useState('docs');
    const tabs = [
      { id: 'docs', label: 'Documents', count: 86 },
      { id: 'binders', label: 'Binders', count: 12 },
      { id: 'reports', label: 'Reports' },
      { id: 'workflows', label: 'Workflows', count: 3 },
      { id: 'archive', label: 'Archive', disabled: true },
    ];
    return (
      <TabList>
        {tabs.map((t) => (
          <Tab
            key={t.id}
            label={t.label}
            count={t.count}
            active={active === t.id}
            disabled={t.disabled}
            onClick={() => setActive(t.id)}
          />
        ))}
      </TabList>
    );
  },
};

export const VerticalTabs: StoryObj = {
  render: () => {
    const [active, setActive] = useState('general');
    const tabs = [
      { id: 'general', label: 'General' },
      { id: 'workflow', label: 'Workflow' },
      { id: 'sharing', label: 'Sharing & Access' },
      { id: 'annotations', label: 'Annotations', count: 4 },
      { id: 'history', label: 'Version History' },
    ];
    return (
      <div className="w-48">
        <VerticalTabList>
          {tabs.map((t) => (
            <VerticalTab
              key={t.id}
              label={t.label}
              count={t.count}
              active={active === t.id}
              onClick={() => setActive(t.id)}
            />
          ))}
        </VerticalTabList>
      </div>
    );
  },
};
