import type { Meta, StoryObj } from '@storybook/react';
import { GlobalHeader } from './GlobalHeader';

const meta: Meta<typeof GlobalHeader> = {
  title: 'Components/GlobalHeader',
  component: GlobalHeader,
  parameters: { layout: 'fullscreen' },
};
export default meta;
type Story = StoryObj<typeof GlobalHeader>;

const tabs = [
  { label: 'Documents', active: true },
  { label: 'Binders' },
  { label: 'Reports' },
  { label: 'Workflows' },
  { label: 'Audits' },
];

export const Default: Story = {
  args: {
    appLabel: 'Vault eTMF',
    tabs,
    user: { name: 'David Mills' },
    onSearch: (q) => console.log('search:', q),
    onCreateClick: () => console.log('create'),
  },
};

export const WithLogo: Story = {
  args: {
    logoSrc: '/assets/veeva-vault-logo.svg',
    appLabel: 'Vault',
    tabs,
    user: { name: 'Jane Doe' },
    onCreateClick: () => {},
  },
};

export const NoTabs: Story = {
  args: {
    appLabel: 'Vault Platform',
    user: { name: 'David Mills' },
    onSearch: () => {},
  },
};
