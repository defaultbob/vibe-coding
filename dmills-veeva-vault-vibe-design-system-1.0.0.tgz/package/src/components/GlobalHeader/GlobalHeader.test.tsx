import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { GlobalHeader } from './GlobalHeader';

const tabs = [
  { label: 'Documents', active: true, onClick: jest.fn() },
  { label: 'Binders', active: false, onClick: jest.fn() },
  { label: 'Reports', active: false, onClick: jest.fn() },
];

describe('GlobalHeader', () => {
  it('renders app label', () => {
    render(<GlobalHeader appLabel="eTMF" />);
    expect(screen.getByText('eTMF')).toBeInTheDocument();
  });

  it('renders search input', () => {
    render(<GlobalHeader />);
    expect(screen.getByRole('searchbox')).toBeInTheDocument();
  });

  it('renders logo image when logoSrc provided', () => {
    render(<GlobalHeader logoSrc="/logo.svg" appLabel="Vault" />);
    expect(screen.getByAltText('Vault')).toBeInTheDocument();
  });

  it('renders tabs', () => {
    render(<GlobalHeader tabs={tabs} />);
    expect(screen.getByText('Documents')).toBeInTheDocument();
    expect(screen.getByText('Binders')).toBeInTheDocument();
  });

  it('active tab has aria-current=page', () => {
    render(<GlobalHeader tabs={tabs} />);
    expect(screen.getByText('Documents').closest('button')).toHaveAttribute('aria-current', 'page');
  });

  it('calls tab onClick', async () => {
    const fn = jest.fn();
    render(<GlobalHeader tabs={[{ label: 'Docs', onClick: fn }]} />);
    await userEvent.click(screen.getByText('Docs'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('renders create button when onCreateClick provided', () => {
    render(<GlobalHeader onCreateClick={() => {}} />);
    expect(screen.getByText('Create')).toBeInTheDocument();
  });

  it('calls onCreateClick when create button clicked', async () => {
    const fn = jest.fn();
    render(<GlobalHeader onCreateClick={fn} />);
    await userEvent.click(screen.getByText('Create'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('renders user name when user provided', () => {
    render(<GlobalHeader user={{ name: 'David Mills' }} />);
    expect(screen.getByText('David Mills')).toBeInTheDocument();
  });

  it('calls onSearch when Enter key pressed in search', async () => {
    const fn = jest.fn();
    render(<GlobalHeader onSearch={fn} />);
    const input = screen.getByRole('searchbox');
    await userEvent.type(input, 'protocol{Enter}');
    expect(fn).toHaveBeenCalledWith('protocol');
  });
});
