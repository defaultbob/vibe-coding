// Font Awesome 6 and Roboto loaded via CDN — see tokens.css
import React, { useState } from 'react';
import { cn } from '../../utils/cn';
import { Avatar } from '../Avatar/Avatar';

export interface GlobalHeaderTab {
  label: string;
  active?: boolean;
  onClick?: () => void;
}

export interface GlobalHeaderProps {
  logoSrc?: string;
  appLabel?: string;
  tabs?: GlobalHeaderTab[];
  onSearch?: (q: string) => void;
  onCreateClick?: () => void;
  user?: { name: string; avatarSrc?: string };
  className?: string;
}

export const GlobalHeader: React.FC<GlobalHeaderProps> = ({
  logoSrc,
  appLabel = 'Vault',
  tabs = [],
  onSearch,
  onCreateClick,
  user,
  className,
}) => {
  const [searchValue, setSearchValue] = useState('');

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && onSearch) {
      onSearch(searchValue);
    }
  };

  return (
    <header className={cn('flex flex-col', className)}>
      {/* Brand bar */}
      <div
        className="flex items-center h-11 px-4 gap-3 bg-vault-header flex-shrink-0"
        style={{ height: 'var(--vault-header-height, 44px)' }}
      >
        {/* Logo */}
        {logoSrc ? (
          <img src={logoSrc} alt={appLabel} className="h-6 w-auto flex-shrink-0" />
        ) : (
          <span className="text-white font-medium text-base leading-none flex-shrink-0">
            {appLabel}
          </span>
        )}

        {/* Search */}
        <div className="flex-1 max-w-xs ml-4">
          <div className="relative">
            <i className="fa-solid fa-magnifying-glass absolute left-2 top-1/2 -translate-y-1/2 text-white/60 text-xs" />
            <input
              type="search"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder="Search documents…"
              aria-label="Global search"
              className="w-full bg-white/10 border border-white/15 rounded-[2px] pl-6 pr-2 h-6 text-xs text-white placeholder-white/60 focus:outline-none focus:border-white/40"
            />
          </div>
        </div>

        <div className="flex-1" />

        {/* Utility icons */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            aria-label="Help"
            className="text-white/85 hover:text-white text-base leading-none"
          >
            <i className="fa-regular fa-circle-question" />
          </button>
          <button
            type="button"
            aria-label="Notifications"
            className="text-white/85 hover:text-white text-base leading-none relative"
          >
            <i className="fa-regular fa-bell" />
          </button>
        </div>

        {/* User avatar */}
        {user && (
          <button
            type="button"
            aria-label={`User menu: ${user.name}`}
            className="flex items-center gap-1.5 ml-2"
          >
            <Avatar
              src={user.avatarSrc}
              alt={user.name}
              size="sm"
            />
            <span className="text-white/85 text-xs hidden sm:inline">{user.name}</span>
          </button>
        )}
      </div>

      {/* Tab bar */}
      {(tabs.length > 0 || onCreateClick) && (
        <div
          className="flex items-center h-10 px-4 bg-vault-bg border-b border-vault-border flex-shrink-0"
          style={{ height: 'var(--vault-tabbar-height, 40px)' }}
        >
          <nav className="flex items-center flex-1 gap-0 h-full" aria-label="Main navigation">
            {tabs.map((tab, i) => (
              <button
                key={i}
                type="button"
                onClick={tab.onClick}
                aria-current={tab.active ? 'page' : undefined}
                className={cn(
                  'relative h-full px-3.5 py-2 text-sm cursor-pointer border-0 bg-transparent transition-colors',
                  tab.active
                    ? 'text-vault-ink font-bold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[3px] after:bg-vault-accent after:content-[\'\']'
                    : 'text-vault-muted hover:text-vault-ink'
                )}
              >
                {tab.label}
              </button>
            ))}
          </nav>
          {onCreateClick && (
            <button
              type="button"
              onClick={onCreateClick}
              className="flex items-center gap-1.5 h-6 px-3 rounded-[2px] bg-vault-primary text-white text-xs font-medium hover:bg-vault-primary-hover transition-colors border border-vault-primary-hover"
            >
              <i className="fa-solid fa-plus text-xs" />
              Create
            </button>
          )}
        </div>
      )}
    </header>
  );
};

GlobalHeader.displayName = 'GlobalHeader';
