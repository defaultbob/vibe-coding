export { GlobalHeader } from './GlobalHeader';
export type { GlobalHeaderProps, GlobalHeaderTab } from './GlobalHeader';
