import type { Meta, StoryObj } from '@storybook/react';
import React, { useState } from 'react';
import { RadioGroup } from './Radio';

const meta: Meta<typeof RadioGroup> = {
  title: 'Components/Radio',
  component: RadioGroup,
};
export default meta;

const options = [
  { value: 'review', label: 'Submit for Review' },
  { value: 'approve', label: 'Approve Directly' },
  { value: 'archive', label: 'Move to Archive', disabled: true },
];

export const Default: StoryObj = {
  render: () => {
    const [value, setValue] = useState('review');
    return (
      <RadioGroup
        name="workflow"
        label="Workflow Action"
        options={options}
        value={value}
        onChange={setValue}
      />
    );
  },
};

export const Required: StoryObj = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <RadioGroup
        name="required-group"
        label="Document Type"
        options={[
          { value: 'protocol', label: 'Protocol' },
          { value: 'consent', label: 'Informed Consent' },
          { value: 'report', label: 'Clinical Report' },
        ]}
        value={value}
        onChange={setValue}
        required
      />
    );
  },
};

export const WithError: StoryObj = {
  render: () => (
    <RadioGroup
      name="err-group"
      label="Lifecycle Action"
      options={options}
      onChange={() => {}}
      error="Please select a workflow action."
    />
  ),
};
