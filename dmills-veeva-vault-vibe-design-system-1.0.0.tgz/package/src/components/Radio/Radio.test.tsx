import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Radio, RadioGroup } from './Radio';

describe('Radio', () => {
  it('renders without crashing', () => {
    render(<Radio name="opt" value="a" />);
    expect(screen.getByRole('radio')).toBeInTheDocument();
  });

  it('renders label', () => {
    render(<Radio name="opt" value="a" label="Option A" />);
    expect(screen.getByText('Option A')).toBeInTheDocument();
  });

  it('calls onChange when clicked', async () => {
    const fn = jest.fn();
    render(<Radio name="opt" value="a" label="A" onChange={fn} />);
    await userEvent.click(screen.getByRole('radio'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not call onChange when disabled', async () => {
    const fn = jest.fn();
    render(<Radio name="opt" value="a" label="A" disabled onChange={fn} />);
    await userEvent.click(screen.getByRole('radio'));
    expect(fn).not.toHaveBeenCalled();
  });

  it('required unchecked shows yellow bg on custom dot', () => {
    const { container } = render(<Radio name="opt" value="a" label="A" required />);
    const customCircle = container.querySelector('[aria-hidden="true"]');
    expect(customCircle).toHaveClass('bg-vault-required');
  });

  it('error shows error message', () => {
    render(<Radio name="opt" value="a" label="A" error="Please select an option" />);
    expect(screen.getByText('Please select an option')).toBeInTheDocument();
  });
});

describe('RadioGroup', () => {
  const options = [
    { value: 'a', label: 'Option A' },
    { value: 'b', label: 'Option B' },
    { value: 'c', label: 'Option C', disabled: true },
  ];

  it('renders all options', () => {
    render(<RadioGroup name="group" options={options} onChange={() => {}} />);
    expect(screen.getByText('Option A')).toBeInTheDocument();
    expect(screen.getByText('Option B')).toBeInTheDocument();
  });

  it('calls onChange with selected value', async () => {
    const fn = jest.fn();
    render(<RadioGroup name="group" options={options} onChange={fn} />);
    await userEvent.click(screen.getByLabelText('Option B'));
    expect(fn).toHaveBeenCalledWith('b');
  });

  it('renders group label', () => {
    render(<RadioGroup name="group" label="Choose one" options={options} onChange={() => {}} />);
    expect(screen.getByText('Choose one')).toBeInTheDocument();
  });
});
