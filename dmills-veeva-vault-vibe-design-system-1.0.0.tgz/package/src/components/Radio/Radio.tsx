import React, { useId } from 'react';
import { cn } from '../../utils/cn';

export interface RadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  error?: string;
}

export interface RadioGroupProps {
  name: string;
  label?: string;
  options: { value: string; label: string; disabled?: boolean }[];
  value?: string;
  onChange?: (value: string) => void;
  required?: boolean;
  error?: string;
  className?: string;
}

export const Radio = React.forwardRef<HTMLInputElement, RadioProps>(
  ({ label, error, className, required, disabled, checked, onChange, id: externalId, ...props }, ref) => {
    const generatedId = useId();
    const id = externalId ?? generatedId;

    return (
      <div className={cn('inline-flex flex-col gap-0.5', className)}>
        <label
          htmlFor={id}
          className={cn(
            'inline-flex items-center gap-2 cursor-pointer select-none text-sm text-vault-ink',
            disabled && 'opacity-60 cursor-not-allowed'
          )}
        >
          <input
            ref={ref}
            id={id}
            type="radio"
            checked={checked}
            onChange={onChange}
            required={required}
            disabled={disabled}
            className="sr-only peer"
            {...props}
          />
          {/* Custom circle */}
          <span
            aria-hidden="true"
            className={cn(
              'flex items-center justify-center w-3.5 h-3.5 rounded-full border flex-shrink-0 transition-colors',
              required && !checked
                ? 'bg-vault-required border-vault-primary'
                : checked
                ? 'bg-vault-primary border-vault-primary'
                : 'bg-vault-bg border-vault-border',
              error && 'border-vault-danger'
            )}
          >
            {checked && (
              <span className="w-1.5 h-1.5 rounded-full bg-white" />
            )}
          </span>
          {label && (
            <span>
              {label}
              {required && <span className="text-vault-danger ml-0.5">*</span>}
            </span>
          )}
        </label>
        {error && <p className="text-label text-vault-danger ml-5">{error}</p>}
      </div>
    );
  }
);

Radio.displayName = 'Radio';

export const RadioGroup: React.FC<RadioGroupProps> = ({
  name,
  label,
  options,
  value,
  onChange,
  required,
  error,
  className,
}) => {
  return (
    <fieldset className={cn('border-0 p-0 m-0', className)}>
      {label && (
        <legend className="text-xs font-bold text-vault-ink mb-1">
          {label}
          {required && <span className="text-vault-danger ml-0.5">*</span>}
        </legend>
      )}
      <div className="flex flex-col gap-1.5">
        {options.map((opt) => (
          <Radio
            key={opt.value}
            name={name}
            value={opt.value}
            label={opt.label}
            checked={value === opt.value}
            onChange={() => onChange?.(opt.value)}
            disabled={opt.disabled}
            required={required}
            error={undefined}
          />
        ))}
      </div>
      {error && <p className="text-label text-vault-danger mt-1">{error}</p>}
    </fieldset>
  );
};
