import type { Meta, StoryObj } from '@storybook/react';
import { LifecycleStage } from './LifecycleStage';

const meta: Meta<typeof LifecycleStage> = {
  title: 'Components/LifecycleStage',
  component: LifecycleStage,
};
export default meta;
type Story = StoryObj<typeof LifecycleStage>;

export const InReview: Story = {
  args: {
    steps: [
      { label: 'Draft', state: 'done' },
      { label: 'In Review', state: 'current' },
      { label: 'Approved', state: 'upcoming' },
      { label: 'Effective', state: 'upcoming' },
      { label: 'Obsolete', state: 'upcoming' },
    ],
  },
};

export const Approved: Story = {
  args: {
    steps: [
      { label: 'Draft', state: 'done' },
      { label: 'In Review', state: 'done' },
      { label: 'Approved', state: 'current' },
      { label: 'Effective', state: 'upcoming' },
      { label: 'Obsolete', state: 'upcoming' },
    ],
  },
};

export const Draft: Story = {
  args: {
    steps: [
      { label: 'Draft', state: 'current' },
      { label: 'In Review', state: 'upcoming' },
      { label: 'Approved', state: 'upcoming' },
    ],
  },
};
