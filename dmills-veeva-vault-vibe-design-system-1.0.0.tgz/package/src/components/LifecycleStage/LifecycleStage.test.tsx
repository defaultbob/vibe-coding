import { render, screen } from '@testing-library/react';
import { LifecycleStage } from './LifecycleStage';

const steps = [
  { label: 'Draft', state: 'done' as const },
  { label: 'In Review', state: 'current' as const },
  { label: 'Approved', state: 'upcoming' as const },
  { label: 'Effective', state: 'upcoming' as const },
];

describe('LifecycleStage', () => {
  it('renders all steps', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByText('Draft')).toBeInTheDocument();
    expect(screen.getByText('In Review')).toBeInTheDocument();
    expect(screen.getByText('Approved')).toBeInTheDocument();
  });

  it('current step has aria-current=step', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByText('In Review').closest('[role="listitem"]')).toHaveAttribute('aria-current', 'step');
  });

  it('done step has blue-lighter bg class', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByText('Draft').closest('[role="listitem"]')).toHaveClass('bg-vault-blue-lighter');
  });

  it('current step has primary bg class', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByText('In Review').closest('[role="listitem"]')).toHaveClass('bg-vault-primary');
  });

  it('upcoming step has gray-light bg class', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByText('Approved').closest('[role="listitem"]')).toHaveClass('bg-vault-gray-light');
  });

  it('has role=list on container', () => {
    render(<LifecycleStage steps={steps} />);
    expect(screen.getByRole('list')).toBeInTheDocument();
  });
});
