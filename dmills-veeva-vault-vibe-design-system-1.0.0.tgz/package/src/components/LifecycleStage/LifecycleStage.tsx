import React from 'react';
import { cn } from '../../utils/cn';

export type StepState = 'done' | 'current' | 'upcoming';

export interface LifecycleStep {
  label: string;
  state: StepState;
}

export interface LifecycleStageProps {
  steps: LifecycleStep[];
  className?: string;
}

const stateStyles: Record<StepState, string> = {
  done: 'bg-vault-blue-lighter text-vault-blue-darker',
  current: 'bg-vault-primary text-white font-bold',
  upcoming: 'bg-vault-gray-light text-vault-muted',
};

export const LifecycleStage: React.FC<LifecycleStageProps> = ({ steps, className }) => {
  return (
    <div className={cn('flex items-center', className)} role="list" aria-label="Lifecycle stages">
      {steps.map((step, i) => {
        const isFirst = i === 0;
        const isLast = i === steps.length - 1;

        const clipClass = isFirst
          ? 'vault-chevron-first'
          : isLast
          ? 'vault-chevron-last'
          : 'vault-chevron';

        return (
          <div
            key={i}
            role="listitem"
            aria-current={step.state === 'current' ? 'step' : undefined}
            className={cn(
              'relative flex items-center justify-center h-8 px-4 text-xs select-none',
              i > 0 && '-ml-2',
              clipClass,
              stateStyles[step.state]
            )}
            style={{ minWidth: 80, zIndex: steps.length - i }}
          >
            <span className="relative z-10 truncate max-w-[120px]">{step.label}</span>
          </div>
        );
      })}
    </div>
  );
};

LifecycleStage.displayName = 'LifecycleStage';
