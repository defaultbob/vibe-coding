import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { PageTitle } from './PageTitle';
import { Button } from '../Button/Button';
import { Badge } from '../Badge/Badge';
import { LifecycleStage } from '../LifecycleStage/LifecycleStage';

const meta: Meta<typeof PageTitle> = {
  title: 'Components/PageTitle',
  component: PageTitle,
};
export default meta;
type Story = StoryObj<typeof PageTitle>;

export const Default: Story = {
  args: { children: 'Study Protocol v2.1' },
};

export const WithBreadcrumbs: Story = {
  args: {
    breadcrumbs: [
      { label: 'Vault', href: '/' },
      { label: 'Documents', href: '/documents' },
      { label: 'Clinical' },
    ],
    children: 'Study Protocol v2.1',
  },
};

export const WithActions: Story = {
  args: {
    breadcrumbs: [{ label: 'Documents', href: '/documents' }, { label: 'Clinical' }],
    children: 'Study Protocol v2.1',
    actions: (
      <>
        <Button>Cancel</Button>
        <Button variant="primary">Start Workflow</Button>
      </>
    ),
  },
};

export const WithMeta: Story = {
  render: () => (
    <PageTitle
      breadcrumbs={[{ label: 'Documents', href: '/' }, { label: 'Clinical Protocols' }]}
      meta={
        <div className="flex items-center gap-3 mt-1">
          <span>Version 2.1</span>
          <Badge tone="green">Approved</Badge>
          <LifecycleStage
            steps={[
              { label: 'Draft', state: 'done' },
              { label: 'In Review', state: 'done' },
              { label: 'Approved', state: 'current' },
              { label: 'Effective', state: 'upcoming' },
            ]}
          />
        </div>
      }
      actions={
        <>
          <Button icon={<i className="fa-solid fa-download" />}>Download</Button>
          <Button variant="primary">Edit</Button>
        </>
      }
    >
      Study Protocol v2.1
    </PageTitle>
  ),
};
