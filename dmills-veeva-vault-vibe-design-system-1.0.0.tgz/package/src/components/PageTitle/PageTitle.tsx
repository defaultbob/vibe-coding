import React from 'react';
import { cn } from '../../utils/cn';

export interface PageTitleBreadcrumb {
  label: string;
  onClick?: () => void;
  href?: string;
}

export interface PageTitleProps {
  breadcrumbs?: PageTitleBreadcrumb[];
  meta?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export const PageTitle: React.FC<PageTitleProps> = ({
  breadcrumbs,
  meta,
  actions,
  children,
  className,
}) => {
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      {/* Breadcrumbs */}
      {breadcrumbs && breadcrumbs.length > 0 && (
        <nav aria-label="Page breadcrumb" className="flex items-center gap-1">
          {breadcrumbs.map((crumb, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <span className="text-vault-muted select-none">›</span>}
              {crumb.href ? (
                <a href={crumb.href} className="text-xs text-vault-muted hover:text-vault-link hover:underline">
                  {crumb.label}
                </a>
              ) : crumb.onClick ? (
                <button
                  type="button"
                  onClick={crumb.onClick}
                  className="text-xs text-vault-muted hover:text-vault-link hover:underline bg-transparent border-0 p-0 cursor-pointer"
                >
                  {crumb.label}
                </button>
              ) : (
                <span className="text-xs text-vault-muted">{crumb.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}

      {/* Title row */}
      <div className="flex items-end justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h1
            className="text-vault-ink pb-2 border-b-2 border-vault-accent inline-block max-w-full"
            style={{ fontSize: '22px', fontWeight: 400, lineHeight: '28px' }}
          >
            {children}
          </h1>
          {meta && <div className="mt-1 text-xs text-vault-muted">{meta}</div>}
        </div>

        {actions && (
          <div className="flex items-center gap-1.5 flex-shrink-0 pb-2">{actions}</div>
        )}
      </div>
    </div>
  );
};

PageTitle.displayName = 'PageTitle';
