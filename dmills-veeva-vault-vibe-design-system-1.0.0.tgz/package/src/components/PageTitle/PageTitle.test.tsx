import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { PageTitle } from './PageTitle';

describe('PageTitle', () => {
  it('renders title text', () => {
    render(<PageTitle>Study Protocol v2.1</PageTitle>);
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('Study Protocol v2.1');
  });

  it('renders breadcrumbs', () => {
    render(
      <PageTitle breadcrumbs={[{ label: 'Documents', href: '/' }, { label: 'Clinical' }]}>
        Study Protocol
      </PageTitle>
    );
    expect(screen.getByText('Documents')).toBeInTheDocument();
    expect(screen.getByText('Clinical')).toBeInTheDocument();
  });

  it('renders actions', () => {
    render(
      <PageTitle actions={<button>Edit</button>}>Title</PageTitle>
    );
    expect(screen.getByRole('button', { name: 'Edit' })).toBeInTheDocument();
  });

  it('renders meta', () => {
    render(<PageTitle meta={<span>Last modified: 2026-05-01</span>}>Title</PageTitle>);
    expect(screen.getByText('Last modified: 2026-05-01')).toBeInTheDocument();
  });

  it('title has orange bottom border style', () => {
    render(<PageTitle>Title</PageTitle>);
    const h1 = screen.getByRole('heading', { level: 1 });
    expect(h1).toHaveClass('border-vault-accent');
  });

  it('calls breadcrumb onClick', async () => {
    const fn = jest.fn();
    render(
      <PageTitle breadcrumbs={[{ label: 'Documents', onClick: fn }, { label: 'Current' }]}>
        Title
      </PageTitle>
    );
    await userEvent.click(screen.getByRole('button', { name: 'Documents' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });
});
