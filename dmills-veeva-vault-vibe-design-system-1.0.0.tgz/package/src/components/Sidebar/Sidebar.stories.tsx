import type { Meta, StoryObj } from '@storybook/react';
import React, { useState } from 'react';
import { Sidebar } from './Sidebar';

const meta: Meta<typeof Sidebar> = {
  title: 'Components/Sidebar',
  component: Sidebar,
};
export default meta;

const groups = [
  {
    title: 'Lifecycle State',
    defaultOpen: true,
    items: [
      { id: 'all', label: 'All Documents', count: 86 },
      { id: 'draft', label: 'Draft', count: 12 },
      { id: 'review', label: 'In Review', count: 5 },
      { id: 'approved', label: 'Approved', count: 34 },
      { id: 'effective', label: 'Effective', count: 29 },
      { id: 'obsolete', label: 'Obsolete', count: 6 },
    ],
  },
  {
    title: 'Document Type',
    defaultOpen: true,
    items: [
      { id: 'protocol', label: 'Protocol', count: 8 },
      { id: 'consent', label: 'Informed Consent', count: 15 },
      { id: 'report', label: 'Clinical Report', count: 22 },
      { id: 'regulatory', label: 'Regulatory', count: 11 },
      { id: 'crf', label: 'Case Report Form', count: 30 },
    ],
  },
  {
    title: 'Study',
    defaultOpen: false,
    items: [
      { id: 'study-001', label: 'TRIAL-001', count: 45 },
      { id: 'study-002', label: 'TRIAL-002', count: 18 },
      { id: 'study-003', label: 'TRIAL-003', count: 23 },
    ],
  },
];

export const Default: StoryObj = {
  render: () => {
    const [activeId, setActiveId] = useState('all');
    return (
      <div className="h-screen">
        <Sidebar groups={groups} activeId={activeId} onSelect={setActiveId} />
      </div>
    );
  },
};

export const NoActive: StoryObj = {
  render: () => <Sidebar groups={groups} />,
};
