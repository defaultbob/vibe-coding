import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Sidebar } from './Sidebar';

const groups = [
  {
    title: 'Lifecycle State',
    defaultOpen: true,
    items: [
      { id: 'draft', label: 'Draft', count: 12 },
      { id: 'review', label: 'In Review', count: 5 },
      { id: 'approved', label: 'Approved', count: 34 },
    ],
  },
  {
    title: 'Document Type',
    defaultOpen: true,
    items: [
      { id: 'protocol', label: 'Protocol', count: 8 },
      { id: 'consent', label: 'Consent Form', count: 15 },
    ],
  },
];

describe('Sidebar', () => {
  it('renders group titles', () => {
    render(<Sidebar groups={groups} />);
    expect(screen.getByText('Lifecycle State')).toBeInTheDocument();
    expect(screen.getByText('Document Type')).toBeInTheDocument();
  });

  it('renders items when group is open', () => {
    render(<Sidebar groups={groups} />);
    expect(screen.getByText('Draft')).toBeInTheDocument();
    expect(screen.getByText('In Review')).toBeInTheDocument();
  });

  it('renders item counts', () => {
    render(<Sidebar groups={groups} />);
    expect(screen.getAllByText('12').length).toBeGreaterThan(0);
    expect(screen.getAllByText('5').length).toBeGreaterThan(0);
  });

  it('calls onSelect when item clicked', async () => {
    const fn = jest.fn();
    render(<Sidebar groups={groups} onSelect={fn} />);
    await userEvent.click(screen.getByText('Draft'));
    expect(fn).toHaveBeenCalledWith('draft');
  });

  it('active item has aria-current', () => {
    render(<Sidebar groups={groups} activeId="review" />);
    const btn = screen.getByText('In Review').closest('button');
    expect(btn).toHaveAttribute('aria-current', 'true');
  });

  it('active item has selected bg class', () => {
    render(<Sidebar groups={groups} activeId="review" />);
    expect(screen.getByText('In Review').closest('button')).toHaveClass('bg-vault-bg-row-selected');
  });

  it('collapses group on header click', async () => {
    render(<Sidebar groups={groups} />);
    const headerBtn = screen.getByRole('button', { name: /Lifecycle State/i });
    await userEvent.click(headerBtn);
    expect(screen.queryByText('Draft')).not.toBeInTheDocument();
  });

  it('expands collapsed group on header click', async () => {
    render(<Sidebar groups={[{ title: 'My Group', defaultOpen: false, items: [{ id: 'x', label: 'Item X' }] }]} />);
    expect(screen.queryByText('Item X')).not.toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /My Group/i }));
    expect(screen.getByText('Item X')).toBeInTheDocument();
  });
});
