// Font Awesome 6 and Roboto loaded via CDN — see tokens.css
import React, { useState } from 'react';
import { cn } from '../../utils/cn';

export interface FacetItem {
  id: string;
  label: string;
  count?: number;
}

export interface FacetGroup {
  title: string;
  items: FacetItem[];
  defaultOpen?: boolean;
}

export interface SidebarProps {
  groups: FacetGroup[];
  activeId?: string;
  onSelect?: (id: string) => void;
  width?: number;
  className?: string;
}

interface GroupState {
  [key: string]: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  groups,
  activeId,
  onSelect,
  width = 220,
  className,
}) => {
  const [openGroups, setOpenGroups] = useState<GroupState>(() => {
    const init: GroupState = {};
    groups.forEach((g) => { init[g.title] = g.defaultOpen !== false; });
    return init;
  });

  const toggleGroup = (title: string) => {
    setOpenGroups((prev) => ({ ...prev, [title]: !prev[title] }));
  };

  return (
    <aside
      className={cn('bg-vault-bg border-r border-vault-border text-sm flex-shrink-0 overflow-y-auto', className)}
      style={{ width }}
      aria-label="Sidebar"
    >
      {groups.map((group) => {
        const isOpen = openGroups[group.title] !== false;
        return (
          <div key={group.title} className="mb-1">
            {/* Group header */}
            <button
              type="button"
              onClick={() => toggleGroup(group.title)}
              aria-expanded={isOpen}
              className="w-full flex items-center justify-between px-3 py-2 text-label font-bold uppercase tracking-wider text-vault-muted hover:text-vault-ink border-0 bg-transparent cursor-pointer"
            >
              <span>{group.title}</span>
              <i
                className={cn(
                  'fa-solid fa-chevron-down text-xs transition-transform',
                  !isOpen && '-rotate-90'
                )}
                aria-hidden="true"
              />
            </button>

            {/* Items */}
            {isOpen && (
              <ul className="list-none p-0 m-0">
                {group.items.map((item) => {
                  const isActive = item.id === activeId;
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => onSelect?.(item.id)}
                        aria-current={isActive ? 'true' : undefined}
                        className={cn(
                          'w-full flex justify-between items-center py-1 text-sm text-vault-ink cursor-pointer border-0 bg-transparent transition-colors',
                          isActive
                            ? 'bg-vault-bg-row-selected border-l-[3px] border-vault-accent font-bold'
                            : 'hover:bg-vault-bg-row-hover border-l-[3px] border-transparent',
                          isActive ? 'pl-[calc(0.875rem-3px)] pr-3.5' : 'px-3.5'
                        )}
                      >
                        <span className="truncate">{item.label}</span>
                        {item.count !== undefined && (
                          <span className="text-vault-muted text-label ml-2 flex-shrink-0">
                            {item.count}
                          </span>
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        );
      })}
    </aside>
  );
};

Sidebar.displayName = 'Sidebar';
