import React, { useState, useRef, useEffect, useId } from 'react';
import { cn } from '../../utils/cn';

export interface DropdownOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface DropdownProps {
  options: DropdownOption[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  label?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  helperText?: string;
  className?: string;
}

export const Dropdown = React.forwardRef<HTMLButtonElement, DropdownProps>(
  (
    {
      options,
      value,
      onChange,
      placeholder = 'Select…',
      label,
      disabled,
      required,
      error,
      helperText,
      className,
    },
    ref
  ) => {
    const id = useId();
    const [open, setOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);
    const selected = options.find((o) => o.value === value);

    useEffect(() => {
      const handleClickOutside = (e: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
          setOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (opt: DropdownOption) => {
      if (opt.disabled) return;
      onChange?.(opt.value);
      setOpen(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen((o) => !o); }
    };

    return (
      <div ref={containerRef} className={cn('relative', className)}>
        {label && (
          <label id={`${id}-label`} className="block text-xs font-bold text-vault-ink mb-0.5">
            {label}
            {required && <span className="text-vault-danger ml-0.5">*</span>}
          </label>
        )}
        <button
          ref={ref}
          type="button"
          id={id}
          aria-haspopup="listbox"
          aria-expanded={open}
          aria-labelledby={label ? `${id}-label ${id}` : undefined}
          onClick={() => !disabled && setOpen((o) => !o)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          className={cn(
            'w-full h-7 rounded-[2px] border text-sm px-2 text-left flex items-center justify-between focus:outline-none focus:border-vault-primary transition-colors',
            required && !value
              ? 'bg-vault-required border-vault-primary'
              : error
              ? 'bg-red-50 border-vault-danger'
              : 'bg-vault-bg border-vault-border',
            disabled && 'bg-vault-bg-alt opacity-60 cursor-not-allowed'
          )}
        >
          <span className={cn(!selected && 'text-vault-placeholder')}>
            {selected ? selected.label : placeholder}
          </span>
          <i
            className={cn(
              'fa-solid fa-chevron-down text-vault-muted text-xs transition-transform ml-2',
              open && 'rotate-180'
            )}
          />
        </button>
        {open && (
          <ul
            role="listbox"
            aria-labelledby={label ? `${id}-label` : id}
            className="absolute z-50 w-full mt-0.5 bg-vault-bg border border-vault-border rounded-[2px] shadow-dropdown max-h-48 overflow-y-auto"
          >
            {options.map((opt) => (
              <li
                key={opt.value}
                role="option"
                aria-selected={opt.value === value}
                aria-disabled={opt.disabled}
                onClick={() => handleSelect(opt)}
                className={cn(
                  'px-2.5 py-1.5 text-sm cursor-pointer',
                  opt.disabled ? 'text-vault-disabled cursor-not-allowed' : 'hover:bg-vault-bg-row-hover',
                  opt.value === value && 'font-bold text-vault-primary'
                )}
              >
                {opt.label}
              </li>
            ))}
          </ul>
        )}
        {error && <p className="text-label text-vault-danger mt-0.5">{error}</p>}
        {helperText && !error && <p className="text-label text-vault-muted mt-0.5">{helperText}</p>}
      </div>
    );
  }
);

Dropdown.displayName = 'Dropdown';
