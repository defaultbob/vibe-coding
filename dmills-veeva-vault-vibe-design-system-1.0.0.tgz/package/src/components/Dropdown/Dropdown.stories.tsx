import type { Meta, StoryObj } from '@storybook/react';
import { Dropdown } from './Dropdown';

const options = [
  { value: 'draft', label: 'Draft' },
  { value: 'review', label: 'In Review' },
  { value: 'approved', label: 'Approved' },
  { value: 'obsolete', label: 'Obsolete', disabled: true },
];

const meta: Meta<typeof Dropdown> = {
  title: 'Components/Dropdown',
  component: Dropdown,
};
export default meta;
type Story = StoryObj<typeof Dropdown>;

export const Default: Story = { args: { options, placeholder: 'Select status…' } };
export const WithLabel: Story = { args: { options, label: 'Lifecycle State', placeholder: 'Select…' } };
export const WithValue: Story = { args: { options, label: 'Status', value: 'approved', onChange: () => {} } };
export const Required: Story = { args: { options, label: 'Document Type', required: true } };
export const WithError: Story = { args: { options, label: 'Status', error: 'Please select a status.' } };
export const Disabled: Story = { args: { options, label: 'Status', disabled: true } };
