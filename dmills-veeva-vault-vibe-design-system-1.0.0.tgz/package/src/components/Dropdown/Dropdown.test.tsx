import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Dropdown } from './Dropdown';

const options = [
  { value: 'draft', label: 'Draft' },
  { value: 'review', label: 'In Review' },
  { value: 'approved', label: 'Approved' },
];

describe('Dropdown', () => {
  it('renders placeholder when no value', () => {
    render(<Dropdown options={options} placeholder="Choose status" />);
    expect(screen.getByText('Choose status')).toBeInTheDocument();
  });

  it('renders selected value', () => {
    render(<Dropdown options={options} value="review" onChange={() => {}} />);
    expect(screen.getByText('In Review')).toBeInTheDocument();
  });

  it('opens dropdown on click', async () => {
    render(<Dropdown options={options} />);
    await userEvent.click(screen.getByRole('button'));
    expect(screen.getByRole('listbox')).toBeInTheDocument();
  });

  it('calls onChange when option selected', async () => {
    const fn = jest.fn();
    render(<Dropdown options={options} onChange={fn} />);
    await userEvent.click(screen.getByRole('button'));
    await userEvent.click(screen.getByText('Approved'));
    expect(fn).toHaveBeenCalledWith('approved');
  });

  it('renders label', () => {
    render(<Dropdown options={options} label="Status" />);
    expect(screen.getByText('Status')).toBeInTheDocument();
  });

  it('required shows yellow bg when no value', () => {
    render(<Dropdown options={options} required />);
    expect(screen.getByRole('button')).toHaveClass('bg-vault-required');
  });

  it('error shows error message', () => {
    render(<Dropdown options={options} error="Required field" />);
    expect(screen.getByText('Required field')).toBeInTheDocument();
  });

  it('is disabled when disabled prop', () => {
    render(<Dropdown options={options} disabled />);
    expect(screen.getByRole('button')).toBeDisabled();
  });
});
