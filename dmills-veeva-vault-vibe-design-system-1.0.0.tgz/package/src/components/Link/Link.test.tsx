import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Link } from './Link';

describe('Link', () => {
  it('renders children', () => {
    render(<Link href="/docs">View Documents</Link>);
    expect(screen.getByText('View Documents')).toBeInTheDocument();
  });

  it('renders as an anchor element', () => {
    render(<Link href="/docs">Docs</Link>);
    expect(screen.getByRole('link')).toBeInTheDocument();
  });

  it('applies vault-link color class', () => {
    render(<Link href="/docs">Docs</Link>);
    expect(screen.getByRole('link')).toHaveClass('text-vault-link');
  });

  it('applies hover:underline class', () => {
    render(<Link href="/docs">Docs</Link>);
    expect(screen.getByRole('link')).toHaveClass('hover:underline');
  });

  it('has correct href', () => {
    render(<Link href="/documents/123">Protocol</Link>);
    expect(screen.getByRole('link')).toHaveAttribute('href', '/documents/123');
  });

  it('calls onClick handler', async () => {
    const fn = jest.fn();
    render(<Link href="#" onClick={fn}>Click me</Link>);
    await userEvent.click(screen.getByRole('link'));
    expect(fn).toHaveBeenCalledTimes(1);
  });
});
