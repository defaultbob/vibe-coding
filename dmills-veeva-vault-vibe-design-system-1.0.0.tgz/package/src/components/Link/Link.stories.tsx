import type { Meta, StoryObj } from '@storybook/react';
import { Link } from './Link';

const meta: Meta<typeof Link> = {
  title: 'Components/Link',
  component: Link,
};
export default meta;
type Story = StoryObj<typeof Link>;

export const Default: Story = { args: { href: '#', children: 'View Document' } };
export const External: Story = { args: { href: 'https://veevavault.com', target: '_blank', children: 'Open in Vault' } };
export const InText: Story = {
  render: () => (
    <p className="text-sm text-vault-ink">
      The <Link href="#">study protocol</Link> has been approved. Please review the <Link href="#">informed consent form</Link>.
    </p>
  ),
};
