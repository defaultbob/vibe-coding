import React, { useId } from 'react';
import { cn } from '../../utils/cn';

export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  indeterminate?: boolean;
  error?: string;
}

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, indeterminate, error, className, required, disabled, checked, onChange, id: externalId, ...props }, ref) => {
    const generatedId = useId();
    const id = externalId ?? generatedId;

    const inputRef = React.useCallback(
      (el: HTMLInputElement | null) => {
        if (el) {
          el.indeterminate = !!indeterminate;
        }
        if (typeof ref === 'function') ref(el);
        else if (ref) (ref as React.MutableRefObject<HTMLInputElement | null>).current = el;
      },
      [indeterminate, ref]
    );

    return (
      <div className={cn('inline-flex flex-col gap-0.5', className)}>
        <label
          htmlFor={id}
          className={cn(
            'inline-flex items-center gap-2 cursor-pointer select-none text-sm text-vault-ink',
            disabled && 'opacity-60 cursor-not-allowed'
          )}
        >
          {/* Hidden native input */}
          <input
            ref={inputRef}
            id={id}
            type="checkbox"
            checked={checked}
            onChange={onChange}
            required={required}
            disabled={disabled}
            className="sr-only peer"
            {...props}
          />
          {/* Custom box */}
          <span
            aria-hidden="true"
            className={cn(
              'flex items-center justify-center w-3.5 h-3.5 rounded-[2px] border flex-shrink-0 transition-colors',
              required && !checked && !indeterminate
                ? 'bg-vault-required border-vault-primary'
                : checked || indeterminate
                ? 'bg-vault-primary border-vault-primary'
                : 'bg-vault-bg border-vault-border',
              error && 'border-vault-danger'
            )}
          >
            {checked && !indeterminate && (
              <svg width="9" height="7" viewBox="0 0 9 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 3.5L3.5 6L8 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
            {indeterminate && (
              <span className="block w-2 h-[1.5px] bg-white rounded-full" />
            )}
          </span>
          {label && (
            <span>
              {label}
              {required && <span className="text-vault-danger ml-0.5">*</span>}
            </span>
          )}
        </label>
        {error && <p className="text-label text-vault-danger ml-5">{error}</p>}
      </div>
    );
  }
);

Checkbox.displayName = 'Checkbox';
