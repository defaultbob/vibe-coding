import type { Meta, StoryObj } from '@storybook/react';
import { Checkbox } from './Checkbox';

const meta: Meta<typeof Checkbox> = {
  title: 'Components/Checkbox',
  component: Checkbox,
};
export default meta;
type Story = StoryObj<typeof Checkbox>;

export const Default: Story = { args: { label: 'Enable notifications' } };
export const Checked: Story = { args: { label: 'I agree to the terms', checked: true, onChange: () => {} } };
export const Indeterminate: Story = { args: { label: 'Select all', indeterminate: true, onChange: () => {} } };
export const Required: Story = { args: { label: 'Accept terms', required: true } };
export const WithError: Story = { args: { label: 'Accept terms', error: 'You must accept the terms to continue.' } };
export const Disabled: Story = { args: { label: 'Archived', disabled: true } };
export const DisabledChecked: Story = { args: { label: 'Read-only option', checked: true, disabled: true, onChange: () => {} } };
