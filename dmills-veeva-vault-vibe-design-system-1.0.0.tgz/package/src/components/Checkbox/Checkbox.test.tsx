import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Checkbox } from './Checkbox';

describe('Checkbox', () => {
  it('renders without crashing', () => {
    render(<Checkbox />);
    expect(screen.getByRole('checkbox')).toBeInTheDocument();
  });

  it('renders label text', () => {
    render(<Checkbox label="Accept terms" />);
    expect(screen.getByText('Accept terms')).toBeInTheDocument();
  });

  it('calls onChange when clicked', async () => {
    const fn = jest.fn();
    render(<Checkbox label="Agree" onChange={fn} />);
    await userEvent.click(screen.getByRole('checkbox'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not call onChange when disabled', async () => {
    const fn = jest.fn();
    render(<Checkbox label="Agree" disabled onChange={fn} />);
    await userEvent.click(screen.getByRole('checkbox'));
    expect(fn).not.toHaveBeenCalled();
  });

  it('required shows asterisk', () => {
    render(<Checkbox label="Accept" required />);
    expect(screen.getByText('*')).toBeInTheDocument();
  });

  it('required unchecked shows yellow bg on custom box', () => {
    const { container } = render(<Checkbox label="Accept" required />);
    const customBox = container.querySelector('[aria-hidden="true"]');
    expect(customBox).toHaveClass('bg-vault-required');
  });

  it('shows error message', () => {
    render(<Checkbox label="Accept" error="This field is required" />);
    expect(screen.getByText('This field is required')).toBeInTheDocument();
  });

  it('checked state applies primary bg', () => {
    const { container } = render(<Checkbox label="Accept" checked onChange={() => {}} />);
    const customBox = container.querySelector('[aria-hidden="true"]');
    expect(customBox).toHaveClass('bg-vault-primary');
  });
});
