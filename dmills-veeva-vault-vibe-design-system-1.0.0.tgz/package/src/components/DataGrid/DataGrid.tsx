import React from 'react';
import { cn } from '../../utils/cn';
import { Checkbox } from '../Checkbox/Checkbox';

export interface Column<T> {
  key: keyof T & string;
  header: string;
  sortable?: boolean;
  width?: number;
  render?: (row: T) => React.ReactNode;
}

export interface DataGridProps<T> {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  selectable?: boolean;
  selectedKeys?: Set<string>;
  onSelectionChange?: (keys: Set<string>) => void;
  sortKey?: string;
  sortDir?: 'asc' | 'desc';
  onSort?: (key: string) => void;
  className?: string;
  emptyMessage?: string;
}

export function DataGrid<T>({
  columns,
  rows,
  rowKey,
  selectable,
  selectedKeys = new Set(),
  onSelectionChange,
  sortKey,
  sortDir,
  onSort,
  className,
  emptyMessage = 'No records found.',
}: DataGridProps<T>) {
  const allSelected = rows.length > 0 && rows.every((r) => selectedKeys.has(rowKey(r)));
  const someSelected = rows.some((r) => selectedKeys.has(rowKey(r))) && !allSelected;

  const handleToggleAll = () => {
    if (!onSelectionChange) return;
    if (allSelected) {
      onSelectionChange(new Set());
    } else {
      onSelectionChange(new Set(rows.map(rowKey)));
    }
  };

  const handleToggleRow = (key: string) => {
    if (!onSelectionChange) return;
    const next = new Set(selectedKeys);
    if (next.has(key)) {
      next.delete(key);
    } else {
      next.add(key);
    }
    onSelectionChange(next);
  };

  const handleSort = (col: Column<T>) => {
    if (col.sortable && onSort) {
      onSort(col.key);
    }
  };

  return (
    <div className={cn('w-full overflow-x-auto', className)}>
      <table className="w-full border-collapse text-sm">
        <thead className="bg-vault-bg-alt">
          <tr>
            {selectable && (
              <th className="w-8 px-2.5 py-2 border-b-2 border-vault-border text-left">
                <Checkbox
                  checked={allSelected}
                  indeterminate={someSelected}
                  onChange={handleToggleAll}
                  aria-label="Select all rows"
                />
              </th>
            )}
            {columns.map((col) => (
              <th
                key={col.key}
                style={col.width ? { width: col.width } : undefined}
                onClick={() => handleSort(col)}
                className={cn(
                  'px-2.5 py-2 text-label font-bold uppercase tracking-[.06em] text-vault-muted border-b-2 border-vault-border text-left',
                  col.sortable && 'cursor-pointer hover:text-vault-ink select-none'
                )}
              >
                <span className="inline-flex items-center gap-1">
                  {col.header}
                  {col.sortable && (
                    <span className="inline-flex flex-col leading-none">
                      {sortKey === col.key ? (
                        sortDir === 'asc' ? (
                          <i className="fa-solid fa-sort-up text-vault-primary" style={{ fontSize: 8 }} />
                        ) : (
                          <i className="fa-solid fa-sort-down text-vault-primary" style={{ fontSize: 8 }} />
                        )
                      ) : (
                        <i className="fa-solid fa-sort text-vault-muted" style={{ fontSize: 8 }} />
                      )}
                    </span>
                  )}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length + (selectable ? 1 : 0)}
                className="px-2.5 py-4 text-center text-vault-muted"
              >
                {emptyMessage}
              </td>
            </tr>
          ) : (
            rows.map((row) => {
              const key = rowKey(row);
              const isSelected = selectedKeys.has(key);
              return (
                <tr
                  key={key}
                  className={cn(
                    'group',
                    isSelected ? 'bg-vault-bg-row-selected' : 'hover:bg-vault-bg-row-hover'
                  )}
                >
                  {selectable && (
                    <td className="w-8 px-2.5 py-1.5 border-b border-vault-gray-light">
                      <Checkbox
                        checked={isSelected}
                        onChange={() => handleToggleRow(key)}
                        aria-label={`Select row ${key}`}
                      />
                    </td>
                  )}
                  {columns.map((col) => (
                    <td key={col.key} className="px-2.5 py-1.5 border-b border-vault-gray-light">
                      {col.render ? col.render(row) : String(row[col.key] ?? '')}
                    </td>
                  ))}
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}

DataGrid.displayName = 'DataGrid';
