import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { DataGrid } from './DataGrid';

interface Doc {
  id: string;
  name: string;
  status: string;
  owner: string;
}

const columns = [
  { key: 'name' as const, header: 'Document Name', sortable: true },
  { key: 'status' as const, header: 'Status' },
  { key: 'owner' as const, header: 'Owner' },
];

const rows: Doc[] = [
  { id: '1', name: 'Protocol v1.0', status: 'Draft', owner: 'Jane Doe' },
  { id: '2', name: 'Consent Form', status: 'Approved', owner: 'Bob Smith' },
  { id: '3', name: 'Site Report', status: 'In Review', owner: 'Carol White' },
];

describe('DataGrid', () => {
  it('renders all column headers', () => {
    render(<DataGrid columns={columns} rows={rows} rowKey={(r) => r.id} />);
    expect(screen.getByText('Document Name')).toBeInTheDocument();
    expect(screen.getByText('Status')).toBeInTheDocument();
    expect(screen.getByText('Owner')).toBeInTheDocument();
  });

  it('renders all row data', () => {
    render(<DataGrid columns={columns} rows={rows} rowKey={(r) => r.id} />);
    expect(screen.getByText('Protocol v1.0')).toBeInTheDocument();
    expect(screen.getByText('Consent Form')).toBeInTheDocument();
  });

  it('renders empty message when no rows', () => {
    render(<DataGrid columns={columns} rows={[]} rowKey={(r) => r.id} emptyMessage="No documents." />);
    expect(screen.getByText('No documents.')).toBeInTheDocument();
  });

  it('renders checkboxes when selectable', () => {
    render(
      <DataGrid columns={columns} rows={rows} rowKey={(r) => r.id} selectable selectedKeys={new Set()} onSelectionChange={() => {}} />
    );
    expect(screen.getByLabelText('Select all rows')).toBeInTheDocument();
  });

  it('applies selected row highlight', () => {
    render(
      <DataGrid
        columns={columns}
        rows={rows}
        rowKey={(r) => r.id}
        selectable
        selectedKeys={new Set(['1'])}
        onSelectionChange={() => {}}
      />
    );
    const rows2 = screen.getAllByRole('row').slice(1); // skip header
    expect(rows2[0]).toHaveClass('bg-vault-bg-row-selected');
  });

  it('calls onSort when sortable header clicked', async () => {
    const fn = jest.fn();
    render(<DataGrid columns={columns} rows={rows} rowKey={(r) => r.id} onSort={fn} />);
    await userEvent.click(screen.getByText('Document Name'));
    expect(fn).toHaveBeenCalledWith('name');
  });

  it('calls onSelectionChange when row checkbox toggled', async () => {
    const fn = jest.fn();
    render(
      <DataGrid
        columns={columns}
        rows={rows}
        rowKey={(r) => r.id}
        selectable
        selectedKeys={new Set()}
        onSelectionChange={fn}
      />
    );
    await userEvent.click(screen.getByLabelText('Select row 1'));
    expect(fn).toHaveBeenCalledWith(new Set(['1']));
  });
});
