import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { DataGrid } from './DataGrid';
import { Badge } from '../Badge/Badge';

interface Doc {
  id: string;
  name: string;
  status: string;
  docType: string;
  owner: string;
  modified: string;
}

const columns = [
  { key: 'name' as const, header: 'Document Name', sortable: true },
  {
    key: 'status' as const,
    header: 'Status',
    render: (row: Doc) => (
      <Badge tone={row.status === 'Approved' ? 'green' : row.status === 'Draft' ? 'bluelt' : 'yellow'}>
        {row.status}
      </Badge>
    ),
  },
  { key: 'docType' as const, header: 'Document Type', sortable: true },
  { key: 'owner' as const, header: 'Owner' },
  { key: 'modified' as const, header: 'Last Modified' },
];

const rows: Doc[] = [
  { id: '1', name: 'Protocol v1.0', status: 'Draft', docType: 'Protocol', owner: 'Jane Doe', modified: '2026-04-15' },
  { id: '2', name: 'Informed Consent Form', status: 'Approved', docType: 'Consent', owner: 'Bob Smith', modified: '2026-04-10' },
  { id: '3', name: 'Site Activation Report', status: 'In Review', docType: 'Report', owner: 'Carol White', modified: '2026-05-01' },
  { id: '4', name: 'IRB Approval Letter', status: 'Approved', docType: 'Regulatory', owner: 'David Mills', modified: '2026-03-22' },
  { id: '5', name: 'Case Report Form', status: 'Draft', docType: 'CRF', owner: 'Eve Johnson', modified: '2026-05-03' },
];

const meta: Meta<typeof DataGrid> = {
  title: 'Components/DataGrid',
  component: DataGrid,
};
export default meta;

export const Default: StoryObj = {
  render: () => (
    <DataGrid columns={columns} rows={rows} rowKey={(r) => r.id} />
  ),
};

export const Selectable: StoryObj = {
  render: () => {
    const [selected, setSelected] = useState<Set<string>>(new Set());
    return (
      <div>
        <p className="text-sm text-vault-muted mb-2">{selected.size} row(s) selected</p>
        <DataGrid
          columns={columns}
          rows={rows}
          rowKey={(r) => r.id}
          selectable
          selectedKeys={selected}
          onSelectionChange={setSelected}
        />
      </div>
    );
  },
};

export const Sortable: StoryObj = {
  render: () => {
    const [sortKey, setSortKey] = useState('name');
    const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
    const handleSort = (key: string) => {
      if (key === sortKey) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
      else { setSortKey(key); setSortDir('asc'); }
    };
    const sorted = [...rows].sort((a, b) => {
      const av = a[sortKey as keyof Doc];
      const bv = b[sortKey as keyof Doc];
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    return <DataGrid columns={columns} rows={sorted} rowKey={(r) => r.id} sortKey={sortKey} sortDir={sortDir} onSort={handleSort} />;
  },
};

export const Empty: StoryObj = {
  render: () => <DataGrid columns={columns} rows={[]} rowKey={(r) => r.id} emptyMessage="No documents match your search." />,
};
