import React, { useState, useRef } from 'react';
import { cn } from '../../utils/cn';

export type HovercardSize = 'xs' | 'sm' | 'md' | 'lg';

export interface HovercardProps {
  content: React.ReactNode;
  size?: HovercardSize;
  children: React.ReactNode;
  className?: string;
}

const sizeWidths: Record<HovercardSize, string> = {
  xs: 'w-36',
  sm: 'w-56',
  md: 'w-72',
  lg: 'w-96',
};

export const Hovercard: React.FC<HovercardProps> = ({ content, size = 'md', children, className }) => {
  const [visible, setVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setVisible(true);
  };

  const hide = () => {
    timerRef.current = setTimeout(() => setVisible(false), 100);
  };

  return (
    <div
      className={cn('relative inline-flex', className)}
      onMouseEnter={show}
      onMouseLeave={hide}
      onFocus={show}
      onBlur={hide}
    >
      {children}
      {visible && (
        <div
          role="tooltip"
          onMouseEnter={show}
          onMouseLeave={hide}
          className={cn(
            'absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2',
            'bg-vault-bg border border-vault-border rounded shadow-overlay',
            sizeWidths[size]
          )}
        >
          <div className="p-3 text-sm text-vault-ink">{content}</div>
        </div>
      )}
    </div>
  );
};

Hovercard.displayName = 'Hovercard';
