import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Hovercard } from './Hovercard';

describe('Hovercard', () => {
  it('renders trigger children', () => {
    render(<Hovercard content="User info"><span>Jane Doe</span></Hovercard>);
    expect(screen.getByText('Jane Doe')).toBeInTheDocument();
  });

  it('shows content on hover', async () => {
    render(<Hovercard content="User info card"><span>Hover me</span></Hovercard>);
    await userEvent.hover(screen.getByText('Hover me'));
    expect(screen.getByRole('tooltip')).toBeInTheDocument();
  });

  it('hides content when not hovered', () => {
    render(<Hovercard content="Card content"><span>Hover me</span></Hovercard>);
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('applies sm size class', async () => {
    render(<Hovercard content="Card" size="sm"><span>Trigger</span></Hovercard>);
    await userEvent.hover(screen.getByText('Trigger'));
    expect(screen.getByRole('tooltip')).toHaveClass('w-56');
  });

  it('applies lg size class', async () => {
    render(<Hovercard content="Card" size="lg"><span>Trigger</span></Hovercard>);
    await userEvent.hover(screen.getByText('Trigger'));
    expect(screen.getByRole('tooltip')).toHaveClass('w-96');
  });
});
