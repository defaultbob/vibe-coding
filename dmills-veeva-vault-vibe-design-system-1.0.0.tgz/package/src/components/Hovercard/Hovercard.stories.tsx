import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Hovercard } from './Hovercard';
import { Avatar } from '../Avatar/Avatar';
import { Badge } from '../Badge/Badge';

const meta: Meta<typeof Hovercard> = {
  title: 'Components/Hovercard',
  component: Hovercard,
};
export default meta;
type Story = StoryObj<typeof Hovercard>;

export const Default: Story = {
  args: {
    content: (
      <div>
        <p className="font-bold">Jane Doe</p>
        <p className="text-vault-muted">Clinical Study Manager</p>
        <p className="text-vault-muted text-label">jane.doe@pharma.com</p>
      </div>
    ),
    children: <span className="text-vault-link cursor-pointer underline">Jane Doe</span>,
    size: 'sm',
  },
};

export const DocumentCard: Story = {
  args: {
    size: 'md',
    content: (
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <p className="font-bold text-xs">Protocol v2.1</p>
          <Badge tone="green">Approved</Badge>
        </div>
        <p className="text-vault-muted text-label">Clinical Protocol</p>
        <p className="text-vault-muted text-label">Owner: David Mills</p>
        <p className="text-vault-muted text-label">Modified: 2026-05-01</p>
      </div>
    ),
    children: <span className="text-vault-link cursor-pointer underline">Protocol v2.1</span>,
  },
};
