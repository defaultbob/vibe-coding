import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Button } from './Button';

describe('Button', () => {
  it('renders children', () => {
    render(<Button>Save</Button>);
    expect(screen.getByRole('button', { name: 'Save' })).toBeInTheDocument();
  });

  it('applies primary variant classes', () => {
    render(<Button variant="primary">Save</Button>);
    expect(screen.getByRole('button')).toHaveClass('bg-vault-primary');
  });

  it('applies danger variant classes', () => {
    render(<Button variant="danger">Delete</Button>);
    expect(screen.getByRole('button')).toHaveClass('bg-vault-danger');
  });

  it('applies ghost variant classes', () => {
    render(<Button variant="ghost">Cancel</Button>);
    expect(screen.getByRole('button')).toHaveClass('bg-transparent');
  });

  it('applies default variant classes', () => {
    render(<Button>Cancel</Button>);
    expect(screen.getByRole('button')).toHaveClass('bg-vault-gray-lighter');
  });

  it('calls onClick when clicked', async () => {
    const fn = jest.fn();
    render(<Button onClick={fn}>Click</Button>);
    await userEvent.click(screen.getByRole('button'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not call onClick when disabled', async () => {
    const fn = jest.fn();
    render(<Button disabled onClick={fn}>Click</Button>);
    await userEvent.click(screen.getByRole('button'));
    expect(fn).not.toHaveBeenCalled();
  });

  it('is disabled when loading', () => {
    render(<Button loading variant="primary">Save</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
  });

  it('renders icon when provided', () => {
    render(<Button icon={<i className="fa-solid fa-plus" data-testid="icon" />}>Add</Button>);
    expect(screen.getByTestId('icon')).toBeInTheDocument();
  });

  it('has correct height class', () => {
    render(<Button>Test</Button>);
    expect(screen.getByRole('button')).toHaveClass('h-6');
  });

  it('has correct border radius class', () => {
    render(<Button>Test</Button>);
    expect(screen.getByRole('button')).toHaveClass('rounded-[2px]');
  });
});
