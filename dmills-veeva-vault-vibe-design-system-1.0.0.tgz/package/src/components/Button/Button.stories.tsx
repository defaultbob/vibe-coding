import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './Button';

const meta: Meta<typeof Button> = {
  title: 'Components/Button',
  component: Button,
};
export default meta;
type Story = StoryObj<typeof Button>;

export const Default: Story = { args: { children: 'Cancel' } };
export const Primary: Story = { args: { variant: 'primary', children: 'Save Document' } };
export const Danger: Story = { args: { variant: 'danger', children: 'Delete' } };
export const Ghost: Story = { args: { variant: 'ghost', children: 'View Details' } };
export const Loading: Story = { args: { variant: 'primary', loading: true, children: 'Saving…' } };
export const Disabled: Story = { args: { variant: 'primary', disabled: true, children: 'Save' } };
export const WithIcon: Story = {
  args: {
    variant: 'primary',
    icon: <i className="fa-solid fa-plus" />,
    children: 'Add Document',
  },
};
export const IconOnlyDefault: Story = {
  args: { icon: <i className="fa-solid fa-ellipsis" /> },
};
