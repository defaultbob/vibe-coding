import React from 'react';
import { cn } from '../../utils/cn';
import { Spinner } from '../Spinner/Spinner';

export type ButtonVariant = 'default' | 'primary' | 'ghost' | 'danger';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  loading?: boolean;
  icon?: React.ReactNode;
}

const variantStyles: Record<ButtonVariant, string> = {
  default:
    'bg-vault-gray-lighter border border-vault-border text-vault-ink hover:bg-vault-gray-light',
  primary:
    'bg-vault-primary border border-vault-primary-hover text-white hover:bg-vault-primary-hover',
  ghost:
    'bg-transparent border-0 text-vault-primary hover:underline',
  danger:
    'bg-vault-danger border border-vault-danger text-white hover:bg-vault-red-dark',
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'default', loading, icon, children, disabled, className, ...props }, ref) => {
    const isDisabled = disabled || loading;

    return (
      <button
        ref={ref}
        disabled={isDisabled}
        className={cn(
          'inline-flex items-center justify-center h-6 rounded-[2px] text-sm font-medium px-3 transition-colors cursor-pointer select-none',
          variantStyles[variant],
          isDisabled && 'opacity-50 cursor-not-allowed pointer-events-none',
          className
        )}
        {...props}
      >
        {loading ? (
          <Spinner size="xs" color={variant === 'primary' || variant === 'danger' ? '#ffffff' : undefined} />
        ) : (
          <>
            {icon && <span className="mr-1 flex items-center">{icon}</span>}
            {children}
          </>
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';
