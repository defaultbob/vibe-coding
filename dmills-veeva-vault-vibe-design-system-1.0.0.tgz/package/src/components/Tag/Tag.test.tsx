import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Tag } from './Tag';

describe('Tag', () => {
  it('renders children', () => {
    render(<Tag>Protocol</Tag>);
    expect(screen.getByText('Protocol')).toBeInTheDocument();
  });

  it('applies default tone class', () => {
    const { container } = render(<Tag>Default</Tag>);
    expect(container.firstChild).toHaveClass('bg-vault-gray-light');
  });

  it('applies active tone class', () => {
    const { container } = render(<Tag tone="active">Active</Tag>);
    expect(container.firstChild).toHaveClass('bg-vault-blue-lighter');
  });

  it('renders remove button when onRemove provided', () => {
    render(<Tag onRemove={() => {}}>Label</Tag>);
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('calls onRemove when × clicked', async () => {
    const fn = jest.fn();
    render(<Tag onRemove={fn}>Label</Tag>);
    await userEvent.click(screen.getByRole('button'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('no remove button when onRemove not provided', () => {
    render(<Tag>Read-only</Tag>);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('disabled tone applies opacity', () => {
    const { container } = render(<Tag tone="disabled">Disabled</Tag>);
    expect(container.firstChild).toHaveClass('opacity-60');
  });
});
