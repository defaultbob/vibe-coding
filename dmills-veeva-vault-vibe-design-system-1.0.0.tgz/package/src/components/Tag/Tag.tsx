import React from 'react';
import { cn } from '../../utils/cn';

export type TagTone = 'default' | 'active' | 'lookup' | 'disabled';

export interface TagProps {
  tone?: TagTone;
  onRemove?: () => void;
  children: React.ReactNode;
  className?: string;
}

const toneStyles: Record<TagTone, string> = {
  default: 'bg-vault-gray-light text-vault-ink border-vault-gray-dark',
  active: 'bg-vault-blue-lighter text-vault-blue-darker border-vault-blue-light',
  lookup: 'bg-vault-green-lightest text-vault-green-darker border-vault-green-light',
  disabled: 'bg-vault-gray-lighter text-vault-disabled border-vault-gray-light opacity-60',
};

export const Tag: React.FC<TagProps> = ({ tone = 'default', onRemove, children, className }) => {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-0.5 h-[18px] px-1.5 text-label rounded-[2px] border',
        toneStyles[tone],
        className
      )}
    >
      <span className="leading-none">{children}</span>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          aria-label={`Remove tag ${children}`}
          className="flex items-center justify-center w-3 h-3 rounded-full hover:bg-black/10 leading-none ml-0.5 flex-shrink-0 text-current"
        >
          ×
        </button>
      )}
    </span>
  );
};

Tag.displayName = 'Tag';
