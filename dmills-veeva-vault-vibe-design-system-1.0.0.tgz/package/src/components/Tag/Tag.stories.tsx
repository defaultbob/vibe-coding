import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Tag } from './Tag';

const meta: Meta<typeof Tag> = {
  title: 'Components/Tag',
  component: Tag,
};
export default meta;
type Story = StoryObj<typeof Tag>;

export const Default: Story = { args: { children: 'Protocol' } };
export const Active: Story = { args: { tone: 'active', children: 'In Review' } };
export const Lookup: Story = { args: { tone: 'lookup', children: 'Approved' } };
export const Disabled: Story = { args: { tone: 'disabled', children: 'Archived' } };
export const Removable: Story = { args: { children: 'Protocol', onRemove: () => {} } };
export const AllTones: StoryObj = {
  render: () => (
    <div className="flex gap-2 flex-wrap">
      <Tag>Default</Tag>
      <Tag tone="active">Active</Tag>
      <Tag tone="lookup">Lookup</Tag>
      <Tag tone="disabled">Disabled</Tag>
      <Tag onRemove={() => {}}>Removable</Tag>
    </div>
  ),
};
