import React from 'react';
import { cn } from '../../utils/cn';

export type BannerTone = 'info' | 'warning' | 'error' | 'success';

export interface BannerProps {
  tone: BannerTone;
  title?: string;
  onClose?: () => void;
  icon?: string;
  children: React.ReactNode;
  className?: string;
}

const toneConfig: Record<BannerTone, { bg: string; iconBg: string; iconColor: string; icon: string }> = {
  info: {
    bg: 'bg-vault-blue-lightest border border-vault-blue-light',
    iconBg: 'bg-vault-primary',
    iconColor: 'text-white',
    icon: 'fa-solid fa-circle-info',
  },
  warning: {
    bg: 'bg-vault-yellow-lighter border border-vault-yellow-darker',
    iconBg: 'bg-vault-accent',
    iconColor: 'text-white',
    icon: 'fa-solid fa-triangle-exclamation',
  },
  error: {
    bg: 'bg-red-50 border border-vault-red-light',
    iconBg: 'bg-vault-danger',
    iconColor: 'text-white',
    icon: 'fa-solid fa-circle-exclamation',
  },
  success: {
    bg: 'bg-vault-green-lightest border border-vault-green-light',
    iconBg: 'bg-vault-success',
    iconColor: 'text-white',
    icon: 'fa-solid fa-circle-check',
  },
};

export const Banner = React.forwardRef<HTMLDivElement, BannerProps>(
  ({ tone, title, onClose, icon, children, className }, ref) => {
    const config = toneConfig[tone];
    const iconClass = icon ?? config.icon;

    return (
      <div
        ref={ref}
        role="region"
        aria-label={title ?? tone}
        className={cn('flex rounded-[2px] shadow-panel overflow-hidden', config.bg, className)}
      >
        {/* Icon column */}
        <div className={cn('flex items-start justify-center w-11 flex-shrink-0 pt-3 pb-3', config.iconBg)}>
          <i className={cn(iconClass, config.iconColor, 'text-base')} aria-hidden="true" />
        </div>
        {/* Body */}
        <div className="flex-1 px-4 py-3">
          {title && <p className="text-sm font-bold text-vault-ink mb-0.5">{title}</p>}
          <div className="text-sm text-vault-ink">{children}</div>
        </div>
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="flex-shrink-0 mr-3 mt-3 text-vault-muted hover:text-vault-ink leading-none text-base"
          >
            ×
          </button>
        )}
      </div>
    );
  }
);

Banner.displayName = 'Banner';
