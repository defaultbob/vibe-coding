import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Banner } from './Banner';

describe('Banner', () => {
  it('renders children', () => {
    render(<Banner tone="info">Informational message here.</Banner>);
    expect(screen.getByText('Informational message here.')).toBeInTheDocument();
  });

  it('renders title when provided', () => {
    render(<Banner tone="success" title="Operation Complete">Details here.</Banner>);
    expect(screen.getByText('Operation Complete')).toBeInTheDocument();
  });

  it('applies info tone bg', () => {
    render(<Banner tone="info">Msg</Banner>);
    const banner = screen.getByRole('region');
    expect(banner).toHaveClass('bg-vault-blue-lightest');
  });

  it('applies error tone bg', () => {
    render(<Banner tone="error">Msg</Banner>);
    const banner = screen.getByRole('region');
    expect(banner).toHaveClass('bg-red-50');
  });

  it('shows close button when onClose provided', () => {
    render(<Banner tone="info" onClose={() => {}}>Msg</Banner>);
    expect(screen.getByRole('button', { name: 'Close' })).toBeInTheDocument();
  });

  it('calls onClose when close button clicked', async () => {
    const fn = jest.fn();
    render(<Banner tone="warning" onClose={fn}>Msg</Banner>);
    await userEvent.click(screen.getByRole('button', { name: 'Close' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });
});
