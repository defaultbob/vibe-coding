import type { Meta, StoryObj } from '@storybook/react';
import { Banner } from './Banner';

const meta: Meta<typeof Banner> = {
  title: 'Components/Banner',
  component: Banner,
};
export default meta;
type Story = StoryObj<typeof Banner>;

export const Info: Story = {
  args: { tone: 'info', title: 'Review Required', children: 'This document requires your review before it can proceed to the next lifecycle state.' },
};
export const Warning: Story = {
  args: { tone: 'warning', title: 'Approaching Deadline', children: 'This document has a review deadline in 2 days.' },
};
export const Error: Story = {
  args: { tone: 'error', title: 'Validation Failed', children: 'Required fields are missing. Please complete all mandatory fields.' },
};
export const Success: Story = {
  args: { tone: 'success', title: 'Document Approved', children: 'The document has been approved and moved to Approved state.' },
};
export const Dismissible: Story = {
  args: { tone: 'info', title: 'New Feature', onClose: () => {}, children: 'Check out the new workflow panel in the sidebar.' },
};
