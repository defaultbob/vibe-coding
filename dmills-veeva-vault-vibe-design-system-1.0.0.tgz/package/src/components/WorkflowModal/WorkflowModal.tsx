import React, { useState } from 'react';
import { cn } from '../../utils/cn';
import { Modal } from '../Modal/Modal';
import { Button } from '../Button/Button';
import { Pill } from '../Pill/Pill';
import { TextInput } from '../TextInput/TextInput';
import { TextArea } from '../TextArea/TextArea';

export interface WorkflowOption {
  id: string;
  label: string;
  description?: string;
}

export interface Participant {
  role: string;
  user: string;
}

export interface WorkflowModalProps {
  documentName?: string;
  documentVersion?: string;
  documentType?: string;
  workflows?: WorkflowOption[];
  initialParticipants?: Participant[];
  onClose?: () => void;
  onStart?: (workflowId: string, participants: Participant[], dueDate: string, note: string) => void;
}

export const WorkflowModal: React.FC<WorkflowModalProps> = ({
  documentName = 'Untitled Document',
  documentVersion = '1.0',
  documentType = 'Document',
  workflows = [],
  initialParticipants = [],
  onClose,
  onStart,
}) => {
  const [selectedWorkflow, setSelectedWorkflow] = useState(workflows[0]?.id ?? '');
  const [participants, setParticipants] = useState<Participant[]>(initialParticipants);
  const [dueDate, setDueDate] = useState('');
  const [note, setNote] = useState('');
  const [newParticipantRole, setNewParticipantRole] = useState('');
  const [newParticipantUser, setNewParticipantUser] = useState('');

  const addParticipant = () => {
    if (newParticipantRole && newParticipantUser) {
      setParticipants((prev) => [
        ...prev,
        { role: newParticipantRole, user: newParticipantUser },
      ]);
      setNewParticipantRole('');
      setNewParticipantUser('');
    }
  };

  const removeParticipant = (index: number) => {
    setParticipants((prev) => prev.filter((_, i) => i !== index));
  };

  const handleStart = () => {
    onStart?.(selectedWorkflow, participants, dueDate, note);
  };

  const workflowOptions = workflows.map((w) => ({
    value: w.id,
    label: w.label,
  }));

  return (
    <Modal
      title="Start Workflow"
      onClose={onClose}
      width={560}
      footer={
        <div className="flex items-center justify-end gap-1.5">
          <Button variant="default" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleStart}
            disabled={!selectedWorkflow}
          >
            Start Workflow
          </Button>
        </div>
      }
    >
      <div className="flex flex-col">
        {/* Document summary strip */}
        <div className="bg-vault-bg-alt border-b border-vault-border px-4 py-2.5">
          <div className="flex items-center gap-3 text-xs text-vault-muted">
            <span className="font-bold text-vault-ink text-sm">{documentName}</span>
            <span>v{documentVersion}</span>
            <span>{documentType}</span>
          </div>
        </div>

        <div className="px-4 py-4 space-y-4">
          {/* Workflow picker */}
          {workflows.length > 0 && (
            <div>
              <p className="text-xs font-bold text-vault-ink mb-2">
                Workflow <span className="text-vault-danger">*</span>
              </p>
              <div className="space-y-1.5">
                {workflows.map((wf) => (
                  <label
                    key={wf.id}
                    className={cn(
                      'flex items-start gap-3 p-3 rounded-[2px] border cursor-pointer transition-colors',
                      selectedWorkflow === wf.id
                        ? 'bg-vault-blue-lightest border-vault-primary'
                        : 'bg-vault-bg border-vault-border hover:bg-vault-bg-row-hover'
                    )}
                  >
                    <input
                      type="radio"
                      name="workflow"
                      value={wf.id}
                      checked={selectedWorkflow === wf.id}
                      onChange={() => setSelectedWorkflow(wf.id)}
                      className="mt-0.5 accent-[#1453b8]"
                    />
                    <div>
                      <p className="text-sm font-medium text-vault-ink">{wf.label}</p>
                      {wf.description && (
                        <p className="text-xs text-vault-muted mt-0.5">{wf.description}</p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Participants */}
          <div>
            <p className="text-xs font-bold text-vault-ink mb-2">Participants</p>
            {participants.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {participants.map((p, i) => (
                  <Pill key={i} onRemove={() => removeParticipant(i)}>
                    {p.role}: {p.user}
                  </Pill>
                ))}
              </div>
            )}
            <div className="flex items-end gap-2">
              <TextInput
                label="Role"
                value={newParticipantRole}
                onChange={(e) => setNewParticipantRole(e.target.value)}
                placeholder="e.g. Reviewer"
                className="flex-1"
              />
              <TextInput
                label="User"
                value={newParticipantUser}
                onChange={(e) => setNewParticipantUser(e.target.value)}
                placeholder="e.g. Jane Doe"
                className="flex-1"
              />
              <Button
                variant="default"
                onClick={addParticipant}
                className="flex-shrink-0 mb-[1px]"
                aria-label="Add participant"
              >
                <i className="fa-solid fa-plus" />
              </Button>
            </div>
          </div>

          {/* Due date + note */}
          <div className="grid grid-cols-2 gap-3">
            <TextInput
              label="Due Date"
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
            <div className="col-span-2">
              <TextArea
                label="Note (optional)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Add a note for reviewers…"
                rows={3}
              />
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

WorkflowModal.displayName = 'WorkflowModal';
