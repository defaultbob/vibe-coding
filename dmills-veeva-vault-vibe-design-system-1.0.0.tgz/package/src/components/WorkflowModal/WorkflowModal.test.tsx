import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { WorkflowModal } from './WorkflowModal';

const workflows = [
  { id: 'review', label: 'Approval Workflow', description: 'Requires two approvers' },
  { id: 'archive', label: 'Archive Workflow', description: 'Moves document to archive' },
];

const participants = [
  { role: 'Reviewer', user: 'Jane Doe' },
];

describe('WorkflowModal', () => {
  it('renders title', () => {
    render(<WorkflowModal />);
    expect(screen.getByText('Start Workflow')).toBeInTheDocument();
  });

  it('renders document name in summary strip', () => {
    render(<WorkflowModal documentName="Protocol v1.0" />);
    expect(screen.getByText('Protocol v1.0')).toBeInTheDocument();
  });

  it('renders document version', () => {
    render(<WorkflowModal documentVersion="2.1" />);
    expect(screen.getByText('v2.1')).toBeInTheDocument();
  });

  it('renders workflow options', () => {
    render(<WorkflowModal workflows={workflows} />);
    expect(screen.getByText('Approval Workflow')).toBeInTheDocument();
    expect(screen.getByText('Archive Workflow')).toBeInTheDocument();
  });

  it('selects first workflow by default', () => {
    render(<WorkflowModal workflows={workflows} />);
    const radio = screen.getAllByRole('radio')[0];
    expect(radio).toBeChecked();
  });

  it('renders initial participants as pills', () => {
    render(<WorkflowModal initialParticipants={participants} />);
    expect(screen.getByText('Reviewer: Jane Doe')).toBeInTheDocument();
  });

  it('calls onClose when cancel clicked', async () => {
    const fn = jest.fn();
    render(<WorkflowModal onClose={fn} />);
    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('calls onStart with selected workflow when Start clicked', async () => {
    const fn = jest.fn();
    render(<WorkflowModal workflows={workflows} onStart={fn} />);
    await userEvent.click(screen.getByRole('button', { name: 'Start Workflow' }));
    expect(fn).toHaveBeenCalledWith('review', [], '', '');
  });

  it('can remove a participant pill', async () => {
    render(<WorkflowModal initialParticipants={participants} />);
    await userEvent.click(screen.getByLabelText('Remove Reviewer: Jane Doe'));
    expect(screen.queryByText('Reviewer: Jane Doe')).not.toBeInTheDocument();
  });
});
