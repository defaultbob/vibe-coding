import type { Meta, StoryObj } from '@storybook/react';
import { WorkflowModal } from './WorkflowModal';

const meta: Meta<typeof WorkflowModal> = {
  title: 'Components/WorkflowModal',
  component: WorkflowModal,
};
export default meta;
type Story = StoryObj<typeof WorkflowModal>;

const workflows = [
  {
    id: 'review',
    label: 'Standard Approval Workflow',
    description: 'Sends to designated reviewers and requires electronic signature.',
  },
  {
    id: 'expedite',
    label: 'Expedited Approval',
    description: 'Fast-track approval for urgent documents. Requires VP signature.',
  },
  {
    id: 'archive',
    label: 'Archive Workflow',
    description: 'Moves the document to archive status after final review.',
  },
];

export const Default: Story = {
  args: {
    documentName: 'Study Protocol v2.1',
    documentVersion: '2.1',
    documentType: 'Clinical Protocol',
    workflows,
    initialParticipants: [
      { role: 'Primary Reviewer', user: 'Jane Doe' },
      { role: 'QA Reviewer', user: 'Bob Smith' },
    ],
    onClose: () => {},
    onStart: (id, p, d, n) => console.log('start', { id, p, d, n }),
  },
};

export const NoWorkflows: Story = {
  args: {
    documentName: 'Consent Form v1.0',
    documentVersion: '1.0',
    documentType: 'Informed Consent',
    workflows: [],
    onClose: () => {},
  },
};
