import React, { useEffect } from 'react';
import { cn } from '../../utils/cn';

export interface ModalProps {
  title?: React.ReactNode;
  onClose?: () => void;
  footer?: React.ReactNode;
  width?: number;
  children: React.ReactNode;
  className?: string;
}

export const Modal = React.forwardRef<HTMLDivElement, ModalProps>(
  ({ title, onClose, footer, width = 520, children, className }, ref) => {
    // Close on Escape
    useEffect(() => {
      const handleKey = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && onClose) onClose();
      };
      document.addEventListener('keydown', handleKey);
      return () => document.removeEventListener('keydown', handleKey);
    }, [onClose]);

    return (
      <div
        className="bg-black/40 fixed inset-0 z-[1000] flex items-center justify-center"
        aria-modal="true"
        role="dialog"
        aria-label={typeof title === 'string' ? title : 'Modal dialog'}
        onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
      >
        <div
          ref={ref}
          className={cn('bg-vault-bg rounded shadow-modal flex flex-col max-h-[90vh] overflow-hidden', className)}
          style={{ width }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          {(title || onClose) && (
            <div className="flex items-center justify-between border-b border-vault-border px-4 py-3 flex-shrink-0">
              {title && (
                <h2 className="text-base font-bold text-vault-ink leading-none">{title}</h2>
              )}
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Close modal"
                  className="ml-auto text-vault-muted hover:text-vault-ink text-xl leading-none flex-shrink-0"
                >
                  ×
                </button>
              )}
            </div>
          )}

          {/* Body */}
          <div className="flex-1 overflow-y-auto">{children}</div>

          {/* Footer */}
          {footer && (
            <div className="border-t border-vault-border px-4 py-2.5 flex justify-end gap-1.5 flex-shrink-0">
              {footer}
            </div>
          )}
        </div>
      </div>
    );
  }
);

Modal.displayName = 'Modal';
