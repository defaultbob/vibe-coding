import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Modal } from './Modal';

describe('Modal', () => {
  it('renders children', () => {
    render(<Modal><p>Modal content here</p></Modal>);
    expect(screen.getByText('Modal content here')).toBeInTheDocument();
  });

  it('renders title', () => {
    render(<Modal title="Edit Document"><p>Content</p></Modal>);
    expect(screen.getByText('Edit Document')).toBeInTheDocument();
  });

  it('renders close button when onClose provided', () => {
    render(<Modal title="Test" onClose={() => {}}><p>Content</p></Modal>);
    expect(screen.getByRole('button', { name: 'Close modal' })).toBeInTheDocument();
  });

  it('calls onClose when close button clicked', async () => {
    const fn = jest.fn();
    render(<Modal title="Test" onClose={fn}><p>Content</p></Modal>);
    await userEvent.click(screen.getByRole('button', { name: 'Close modal' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('renders footer', () => {
    render(<Modal footer={<button>Save</button>}><p>Content</p></Modal>);
    expect(screen.getByRole('button', { name: 'Save' })).toBeInTheDocument();
  });

  it('has role=dialog', () => {
    render(<Modal><p>Content</p></Modal>);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('calls onClose on Escape key', async () => {
    const fn = jest.fn();
    render(<Modal title="Test" onClose={fn}><p>Content</p></Modal>);
    await userEvent.keyboard('{Escape}');
    expect(fn).toHaveBeenCalledTimes(1);
  });
});
