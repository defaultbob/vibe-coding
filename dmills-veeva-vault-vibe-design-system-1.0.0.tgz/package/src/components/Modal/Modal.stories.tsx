import type { Meta, StoryObj } from '@storybook/react';
import { Modal } from './Modal';
import { Button } from '../Button/Button';

const meta: Meta<typeof Modal> = {
  title: 'Components/Modal',
  component: Modal,
};
export default meta;
type Story = StoryObj<typeof Modal>;

export const Default: Story = {
  args: {
    title: 'Edit Document Properties',
    onClose: () => {},
    footer: (
      <>
        <Button variant="default">Cancel</Button>
        <Button variant="primary">Save Changes</Button>
      </>
    ),
    children: (
      <div className="px-4 py-4 space-y-3">
        <p className="text-sm">Modify the document metadata below.</p>
        <div>
          <label className="block text-xs font-bold text-vault-ink mb-0.5">Document Name</label>
          <input className="w-full h-7 rounded-[2px] border border-vault-border px-2 text-sm" defaultValue="Protocol v1.0" />
        </div>
      </div>
    ),
  },
};

export const Narrow: Story = {
  args: {
    title: 'Confirm Submission',
    width: 380,
    onClose: () => {},
    footer: (
      <>
        <Button>Cancel</Button>
        <Button variant="primary">Submit</Button>
      </>
    ),
    children: (
      <div className="px-4 py-4">
        <p className="text-sm">Are you sure you want to submit this document for review?</p>
      </div>
    ),
  },
};
