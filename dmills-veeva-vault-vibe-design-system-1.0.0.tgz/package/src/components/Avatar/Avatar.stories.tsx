import type { Meta, StoryObj } from '@storybook/react';
import { Avatar } from './Avatar';

const meta: Meta<typeof Avatar> = {
  title: 'Components/Avatar',
  component: Avatar,
};
export default meta;
type Story = StoryObj<typeof Avatar>;

export const WithInitials: Story = { args: { initials: 'DM', alt: 'David Mills', size: 'md' } };
export const Small: Story = { args: { initials: 'JD', alt: 'Jane Doe', size: 'sm' } };
export const Large: Story = { args: { initials: 'JD', alt: 'Jane Doe', size: 'lg' } };
export const Online: Story = { args: { initials: 'JD', alt: 'Jane Doe', online: true } };
export const Offline: Story = { args: { initials: 'JD', alt: 'Jane Doe', online: false } };
export const WithImage: Story = {
  args: {
    src: 'https://i.pravatar.cc/150?img=5',
    alt: 'Profile photo',
    size: 'lg',
  },
};
