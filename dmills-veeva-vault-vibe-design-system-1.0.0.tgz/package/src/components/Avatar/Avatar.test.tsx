import { render, screen } from '@testing-library/react';
import { Avatar } from './Avatar';

describe('Avatar', () => {
  it('renders image when src provided', () => {
    render(<Avatar src="/test.jpg" alt="Jane Doe" />);
    expect(screen.getByRole('img', { name: 'Jane Doe' })).toBeInTheDocument();
  });

  it('renders initials when no src', () => {
    render(<Avatar initials="JD" alt="Jane Doe" />);
    expect(screen.getByText('JD')).toBeInTheDocument();
  });

  it('derives initials from alt when no initials prop', () => {
    render(<Avatar alt="Jane Doe" />);
    expect(screen.getByText('JD')).toBeInTheDocument();
  });

  it('applies sm size class', () => {
    render(<Avatar initials="AB" size="sm" />);
    const span = screen.getByText('AB');
    expect(span).toHaveClass('w-5');
  });

  it('applies lg size class', () => {
    render(<Avatar initials="AB" size="lg" />);
    const span = screen.getByText('AB');
    expect(span).toHaveClass('w-9');
  });

  it('shows online indicator when online=true', () => {
    render(<Avatar initials="AB" online={true} />);
    expect(screen.getByLabelText('Online')).toBeInTheDocument();
  });

  it('shows offline indicator when online=false', () => {
    render(<Avatar initials="AB" online={false} />);
    expect(screen.getByLabelText('Offline')).toBeInTheDocument();
  });

  it('no indicator when online not provided', () => {
    const { container } = render(<Avatar initials="AB" />);
    expect(container.querySelector('[aria-label="Online"]')).not.toBeInTheDocument();
  });
});
