import React from 'react';
import { cn } from '../../utils/cn';

export type AvatarSize = 'sm' | 'md' | 'lg';

export interface AvatarProps {
  src?: string;
  alt?: string;
  initials?: string;
  size?: AvatarSize;
  online?: boolean;
  className?: string;
}

const sizeMap: Record<AvatarSize, { container: string; text: string; indicator: string }> = {
  sm: { container: 'w-5 h-5', text: 'text-[9px]', indicator: 'w-1.5 h-1.5' },
  md: { container: 'w-7 h-7', text: 'text-label', indicator: 'w-2 h-2' },
  lg: { container: 'w-9 h-9', text: 'text-xs', indicator: 'w-2.5 h-2.5' },
};

export const Avatar = React.forwardRef<HTMLDivElement, AvatarProps>(
  ({ src, alt = '', initials, size = 'md', online, className }, ref) => {
    const sizes = sizeMap[size];
    const derivedInitials = initials ?? alt.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2);

    return (
      <div
        ref={ref}
        className={cn('relative inline-flex flex-shrink-0', className)}
        aria-label={alt || initials}
      >
        {src ? (
          <img
            src={src}
            alt={alt}
            className={cn(sizes.container, 'rounded-full object-cover')}
          />
        ) : (
          <span
            className={cn(
              sizes.container,
              sizes.text,
              'rounded-full bg-vault-orange text-white flex items-center justify-center font-medium select-none'
            )}
            aria-hidden="true"
          >
            {derivedInitials}
          </span>
        )}
        {online !== undefined && (
          <span
            className={cn(
              sizes.indicator,
              'absolute bottom-0 right-0 rounded-full border border-white',
              online ? 'bg-vault-success' : 'bg-vault-muted'
            )}
            aria-label={online ? 'Online' : 'Offline'}
          />
        )}
      </div>
    );
  }
);

Avatar.displayName = 'Avatar';
