import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Dialog } from './Dialog';

describe('Dialog', () => {
  it('renders title', () => {
    render(<Dialog title="Delete Document" message="Are you sure?" onConfirm={() => {}} onCancel={() => {}} />);
    expect(screen.getByText('Delete Document')).toBeInTheDocument();
  });

  it('renders message', () => {
    render(<Dialog title="Confirm" message="Are you sure you want to proceed?" />);
    expect(screen.getByText('Are you sure you want to proceed?')).toBeInTheDocument();
  });

  it('renders confirm and cancel buttons', () => {
    render(<Dialog confirmLabel="Delete" cancelLabel="Cancel" onConfirm={() => {}} onCancel={() => {}} />);
    expect(screen.getByRole('button', { name: 'Delete' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeInTheDocument();
  });

  it('calls onConfirm when confirm clicked', async () => {
    const fn = jest.fn();
    render(<Dialog confirmLabel="OK" onConfirm={fn} onCancel={() => {}} />);
    await userEvent.click(screen.getByRole('button', { name: 'OK' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('calls onCancel when cancel clicked', async () => {
    const fn = jest.fn();
    render(<Dialog onConfirm={() => {}} onCancel={fn} />);
    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('danger variant shows warning icon and message', () => {
    render(<Dialog variant="danger" message="Delete this?" onConfirm={() => {}} onCancel={() => {}} />);
    expect(screen.getByText('This action cannot be undone.')).toBeInTheDocument();
  });

  it('danger variant uses danger button', () => {
    render(<Dialog variant="danger" confirmLabel="Delete" onConfirm={() => {}} onCancel={() => {}} />);
    expect(screen.getByRole('button', { name: 'Delete' })).toHaveClass('bg-vault-danger');
  });
});
