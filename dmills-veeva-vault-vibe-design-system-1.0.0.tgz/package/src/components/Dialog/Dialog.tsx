import React from 'react';
import { cn } from '../../utils/cn';
import { Modal } from '../Modal/Modal';
import { Button } from '../Button/Button';

export interface DialogProps {
  title?: string;
  message?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'default' | 'danger';
  onConfirm?: () => void;
  onCancel?: () => void;
  onClose?: () => void;
  loading?: boolean;
}

export const Dialog: React.FC<DialogProps> = ({
  title = 'Confirm',
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'default',
  onConfirm,
  onCancel,
  onClose,
  loading,
}) => {
  const handleClose = onClose ?? onCancel;

  return (
    <Modal
      title={title}
      onClose={handleClose}
      width={400}
      footer={
        <div className="flex items-center justify-end gap-1.5">
          <Button variant="default" onClick={onCancel ?? handleClose}>
            {cancelLabel}
          </Button>
          <Button
            variant={variant === 'danger' ? 'danger' : 'primary'}
            onClick={onConfirm}
            loading={loading}
          >
            {confirmLabel}
          </Button>
        </div>
      }
    >
      <div className={cn('px-4 py-4 text-sm text-vault-ink')}>
        {variant === 'danger' && (
          <div className="flex items-center gap-2 mb-3 text-vault-danger">
            <i className="fa-solid fa-triangle-exclamation text-base" />
            <span className="font-medium">This action cannot be undone.</span>
          </div>
        )}
        {message}
      </div>
    </Modal>
  );
};

Dialog.displayName = 'Dialog';
