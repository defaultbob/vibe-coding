import type { Meta, StoryObj } from '@storybook/react';
import { Dialog } from './Dialog';

const meta: Meta<typeof Dialog> = {
  title: 'Components/Dialog',
  component: Dialog,
};
export default meta;
type Story = StoryObj<typeof Dialog>;

export const Default: Story = {
  args: {
    title: 'Confirm Action',
    message: 'Are you sure you want to proceed with this action?',
    confirmLabel: 'Confirm',
    cancelLabel: 'Cancel',
  },
};

export const Danger: Story = {
  args: {
    title: 'Delete Document',
    message: 'This will permanently delete "Protocol v1.0" and all associated versions.',
    confirmLabel: 'Delete Document',
    cancelLabel: 'Cancel',
    variant: 'danger',
  },
};

export const Loading: Story = {
  args: {
    title: 'Submit for Review',
    message: 'Are you sure you want to submit this document for review?',
    confirmLabel: 'Submit',
    cancelLabel: 'Cancel',
    loading: true,
  },
};
