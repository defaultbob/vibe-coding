import React, { useState } from 'react';
import { cn } from '../../utils/cn';

export interface SearchBoxProps {
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  autoSearch?: boolean;
}

export const SearchBox = React.forwardRef<HTMLInputElement, SearchBoxProps>(
  (
    {
      value: controlledValue,
      onChange,
      onSearch,
      placeholder = 'Search…',
      disabled,
      className,
      autoSearch = true,
    },
    ref
  ) => {
    const [internalValue, setInternalValue] = useState('');
    const value = controlledValue !== undefined ? controlledValue : internalValue;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const v = e.target.value;
      if (controlledValue === undefined) setInternalValue(v);
      onChange?.(v);
      if (autoSearch) onSearch?.(v);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter') onSearch?.(value);
      if (e.key === 'Escape') {
        if (controlledValue === undefined) setInternalValue('');
        onChange?.('');
        onSearch?.('');
      }
    };

    const handleClear = () => {
      if (controlledValue === undefined) setInternalValue('');
      onChange?.('');
      onSearch?.('');
    };

    return (
      <div className={cn('relative flex items-center', className)}>
        <i
          className="fa-solid fa-magnifying-glass absolute left-2 text-vault-muted text-xs pointer-events-none"
          aria-hidden="true"
        />
        <input
          ref={ref}
          type="search"
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          aria-label="Search"
          className={cn(
            'w-full h-7 rounded-[2px] border border-vault-border bg-vault-bg text-sm pl-7 pr-7 focus:outline-none focus:border-vault-primary transition-colors',
            disabled && 'bg-vault-bg-alt opacity-60 cursor-not-allowed'
          )}
        />
        {value && (
          <button
            type="button"
            onClick={handleClear}
            aria-label="Clear search"
            className="absolute right-2 text-vault-muted hover:text-vault-ink text-sm"
          >
            ×
          </button>
        )}
      </div>
    );
  }
);

SearchBox.displayName = 'SearchBox';
