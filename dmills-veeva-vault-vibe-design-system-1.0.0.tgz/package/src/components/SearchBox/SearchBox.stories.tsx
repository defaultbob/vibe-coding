import type { Meta, StoryObj } from '@storybook/react';
import React, { useState } from 'react';
import { SearchBox } from './SearchBox';

const meta: Meta<typeof SearchBox> = {
  title: 'Components/SearchBox',
  component: SearchBox,
};
export default meta;

export const Default: StoryObj = {
  render: () => {
    const [value, setValue] = useState('');
    return <SearchBox value={value} onChange={setValue} placeholder="Search documents…" />;
  },
};

export const Controlled: StoryObj = {
  render: () => {
    const [value, setValue] = useState('protocol');
    return (
      <div className="space-y-2">
        <SearchBox value={value} onChange={setValue} onSearch={(v) => console.log('search:', v)} />
        <p className="text-sm text-vault-muted">Current value: {value || '(empty)'}</p>
      </div>
    );
  },
};

export const Disabled: StoryObj = {
  render: () => <SearchBox disabled placeholder="Search…" />,
};
