import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SearchBox } from './SearchBox';

describe('SearchBox', () => {
  it('renders without crashing', () => {
    render(<SearchBox />);
    expect(screen.getByRole('searchbox')).toBeInTheDocument();
  });

  it('shows placeholder', () => {
    render(<SearchBox placeholder="Find documents…" />);
    expect(screen.getByPlaceholderText('Find documents…')).toBeInTheDocument();
  });

  it('calls onChange as user types', async () => {
    const fn = jest.fn();
    render(<SearchBox onChange={fn} />);
    await userEvent.type(screen.getByRole('searchbox'), 'hello');
    expect(fn).toHaveBeenCalled();
    expect(fn).toHaveBeenLastCalledWith('hello');
  });

  it('calls onSearch on Enter', async () => {
    const fn = jest.fn();
    render(<SearchBox onSearch={fn} />);
    await userEvent.type(screen.getByRole('searchbox'), 'protocol{Enter}');
    expect(fn).toHaveBeenCalledWith('protocol');
  });

  it('shows clear button when value entered', async () => {
    render(<SearchBox />);
    await userEvent.type(screen.getByRole('searchbox'), 'test');
    expect(screen.getByRole('button', { name: 'Clear search' })).toBeInTheDocument();
  });

  it('clears value when clear button clicked', async () => {
    render(<SearchBox />);
    await userEvent.type(screen.getByRole('searchbox'), 'test');
    await userEvent.click(screen.getByRole('button', { name: 'Clear search' }));
    expect(screen.getByRole('searchbox')).toHaveValue('');
  });

  it('is disabled when disabled prop', () => {
    render(<SearchBox disabled />);
    expect(screen.getByRole('searchbox')).toBeDisabled();
  });
});
