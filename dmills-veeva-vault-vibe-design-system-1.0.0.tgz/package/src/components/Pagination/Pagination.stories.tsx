import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Pagination } from './Pagination';

const meta: Meta<typeof Pagination> = {
  title: 'Components/Pagination',
  component: Pagination,
};
export default meta;

export const Default: StoryObj = {
  render: () => {
    const [page, setPage] = useState(1);
    return <Pagination page={page} pageCount={20} totalItems={387} onPageChange={setPage} />;
  },
};

export const MiddlePage: StoryObj = {
  render: () => {
    const [page, setPage] = useState(5);
    return <Pagination page={page} pageCount={10} totalItems={100} onPageChange={setPage} />;
  },
};

export const SinglePage: StoryObj = {
  render: () => <Pagination page={1} pageCount={1} totalItems={5} onPageChange={() => {}} />,
};
