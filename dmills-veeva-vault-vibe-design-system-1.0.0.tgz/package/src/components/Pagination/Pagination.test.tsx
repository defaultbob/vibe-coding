import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Pagination } from './Pagination';

describe('Pagination', () => {
  it('renders page info', () => {
    render(<Pagination page={2} pageCount={10} onPageChange={() => {}} />);
    expect(screen.getByLabelText('Current page')).toHaveValue('2');
    expect(screen.getByText('of 10')).toBeInTheDocument();
  });

  it('renders total items when provided', () => {
    render(<Pagination page={1} pageCount={5} totalItems={48} onPageChange={() => {}} />);
    expect(screen.getByText('48 records')).toBeInTheDocument();
  });

  it('calls onPageChange with page+1 on next', async () => {
    const fn = jest.fn();
    render(<Pagination page={2} pageCount={10} onPageChange={fn} />);
    await userEvent.click(screen.getByLabelText('Next page'));
    expect(fn).toHaveBeenCalledWith(3);
  });

  it('calls onPageChange with page-1 on prev', async () => {
    const fn = jest.fn();
    render(<Pagination page={5} pageCount={10} onPageChange={fn} />);
    await userEvent.click(screen.getByLabelText('Previous page'));
    expect(fn).toHaveBeenCalledWith(4);
  });

  it('prev button disabled on page 1', () => {
    render(<Pagination page={1} pageCount={10} onPageChange={() => {}} />);
    expect(screen.getByLabelText('Previous page')).toBeDisabled();
  });

  it('next button disabled on last page', () => {
    render(<Pagination page={10} pageCount={10} onPageChange={() => {}} />);
    expect(screen.getByLabelText('Next page')).toBeDisabled();
  });

  it('calls onPageChange when Enter pressed in input', async () => {
    const fn = jest.fn();
    render(<Pagination page={1} pageCount={10} onPageChange={fn} />);
    const input = screen.getByLabelText('Current page');
    await userEvent.clear(input);
    await userEvent.type(input, '5{Enter}');
    expect(fn).toHaveBeenCalledWith(5);
  });
});
