import React, { useState } from 'react';
import { cn } from '../../utils/cn';

export interface PaginationProps {
  page: number;
  pageCount: number;
  totalItems?: number;
  onPageChange: (p: number) => void;
  className?: string;
}

export const Pagination: React.FC<PaginationProps> = ({
  page,
  pageCount,
  totalItems,
  onPageChange,
  className,
}) => {
  const [inputValue, setInputValue] = useState(String(page));

  const goTo = (p: number) => {
    const clamped = Math.max(1, Math.min(p, pageCount));
    onPageChange(clamped);
    setInputValue(String(clamped));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleInputBlur = () => {
    const n = parseInt(inputValue, 10);
    if (!isNaN(n)) goTo(n);
    else setInputValue(String(page));
  };

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const n = parseInt(inputValue, 10);
      if (!isNaN(n)) goTo(n);
    }
  };

  return (
    <div className={cn('flex items-center gap-2 text-sm text-vault-muted', className)}>
      {/* Total count */}
      {totalItems !== undefined && (
        <span className="mr-2 text-vault-muted">
          {totalItems} {totalItems === 1 ? 'record' : 'records'}
        </span>
      )}

      {/* Prev */}
      <button
        type="button"
        aria-label="Previous page"
        disabled={page <= 1}
        onClick={() => goTo(page - 1)}
        className={cn(
          'w-6 h-6 rounded-full flex items-center justify-center border border-vault-border text-vault-ink transition-colors',
          page <= 1
            ? 'opacity-40 cursor-not-allowed'
            : 'hover:bg-vault-bg-row-hover cursor-pointer'
        )}
      >
        <i className="fa-solid fa-chevron-left text-xs" />
      </button>

      {/* Page input */}
      <div className="flex items-center gap-1">
        <input
          type="text"
          aria-label="Current page"
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleInputBlur}
          onKeyDown={handleInputKeyDown}
          className="w-8 h-6 text-center text-sm border border-vault-border rounded-[2px] focus:outline-none focus:border-vault-primary"
        />
        <span className="text-vault-muted">of {pageCount}</span>
      </div>

      {/* Next */}
      <button
        type="button"
        aria-label="Next page"
        disabled={page >= pageCount}
        onClick={() => goTo(page + 1)}
        className={cn(
          'w-6 h-6 rounded-full flex items-center justify-center border border-vault-border text-vault-ink transition-colors',
          page >= pageCount
            ? 'opacity-40 cursor-not-allowed'
            : 'hover:bg-vault-bg-row-hover cursor-pointer'
        )}
      >
        <i className="fa-solid fa-chevron-right text-xs" />
      </button>
    </div>
  );
};

Pagination.displayName = 'Pagination';
