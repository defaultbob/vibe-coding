import React from 'react';
import { cn } from '../../utils/cn';

export type AlertTone = 'success' | 'info' | 'error' | 'warning';

export interface AlertProps {
  tone: AlertTone;
  onClose?: () => void;
  icon?: string;
  children: React.ReactNode;
  className?: string;
}

const toneStyles: Record<AlertTone, string> = {
  success: 'bg-vault-green-lightest text-vault-green-darker border border-vault-green-light',
  info: 'bg-vault-yellow-lightest text-vault-blue-darker border border-vault-blue-light',
  error: 'bg-red-100 text-vault-red-darker border border-vault-red-light',
  warning: 'bg-orange-50 text-vault-orange-darker border border-vault-orange-light',
};

const defaultIcons: Record<AlertTone, string> = {
  success: 'fa-solid fa-circle-check',
  info: 'fa-solid fa-circle-info',
  error: 'fa-solid fa-circle-exclamation',
  warning: 'fa-solid fa-triangle-exclamation',
};

const iconColors: Record<AlertTone, string> = {
  success: 'text-vault-success',
  info: 'text-vault-primary',
  error: 'text-vault-danger',
  warning: 'text-vault-accent',
};

export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ tone, onClose, icon, children, className }, ref) => {
    const iconClass = icon ?? defaultIcons[tone];

    return (
      <div
        ref={ref}
        role="alert"
        className={cn(
          'flex items-center h-[38px] px-3 rounded-[2px] text-sm gap-2',
          toneStyles[tone],
          className
        )}
      >
        <i className={cn(iconClass, iconColors[tone], 'flex-shrink-0')} aria-hidden="true" />
        <span className="flex-1 truncate">{children}</span>
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close alert"
            className="ml-1 flex-shrink-0 text-current opacity-60 hover:opacity-100 leading-none text-base"
          >
            ×
          </button>
        )}
      </div>
    );
  }
);

Alert.displayName = 'Alert';
