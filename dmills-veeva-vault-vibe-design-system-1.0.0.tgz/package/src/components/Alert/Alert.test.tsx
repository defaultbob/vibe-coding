import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Alert } from './Alert';

describe('Alert', () => {
  it('renders children', () => {
    render(<Alert tone="info">This is an info message</Alert>);
    expect(screen.getByRole('alert')).toHaveTextContent('This is an info message');
  });

  it('applies correct tone class for success', () => {
    render(<Alert tone="success">Done!</Alert>);
    expect(screen.getByRole('alert')).toHaveClass('bg-vault-green-lightest');
  });

  it('applies correct tone class for error', () => {
    render(<Alert tone="error">Error!</Alert>);
    expect(screen.getByRole('alert')).toHaveClass('bg-red-100');
  });

  it('renders close button when onClose provided', () => {
    render(<Alert tone="info" onClose={() => {}}>Msg</Alert>);
    expect(screen.getByRole('button', { name: 'Close alert' })).toBeInTheDocument();
  });

  it('calls onClose when close button clicked', async () => {
    const fn = jest.fn();
    render(<Alert tone="warning" onClose={fn}>Warning</Alert>);
    await userEvent.click(screen.getByRole('button', { name: 'Close alert' }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('does not render close button when no onClose', () => {
    render(<Alert tone="success">OK</Alert>);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('has role=alert', () => {
    render(<Alert tone="error">Oops</Alert>);
    expect(screen.getByRole('alert')).toBeInTheDocument();
  });
});
