import type { Meta, StoryObj } from '@storybook/react';
import { Alert } from './Alert';

const meta: Meta<typeof Alert> = {
  title: 'Components/Alert',
  component: Alert,
};
export default meta;
type Story = StoryObj<typeof Alert>;

export const Info: Story = { args: { tone: 'info', children: 'Document has been submitted for review.' } };
export const Success: Story = { args: { tone: 'success', children: 'Changes saved successfully.' } };
export const Warning: Story = { args: { tone: 'warning', children: 'This action cannot be undone.' } };
export const Error: Story = { args: { tone: 'error', children: 'Failed to save. Please try again.' } };
export const Dismissible: Story = {
  args: { tone: 'info', onClose: () => {}, children: 'Click × to dismiss this alert.' },
};
