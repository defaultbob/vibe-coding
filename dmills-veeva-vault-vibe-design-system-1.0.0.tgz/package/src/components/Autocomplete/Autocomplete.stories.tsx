import type { Meta, StoryObj } from '@storybook/react';
import { Autocomplete } from './Autocomplete';

const options = [
  { value: 'alice', label: 'Alice Smith' },
  { value: 'bob', label: 'Bob Jones' },
  { value: 'carol', label: 'Carol White' },
  { value: 'david', label: 'David Mills' },
  { value: 'eve', label: 'Eve Johnson' },
];

const meta: Meta<typeof Autocomplete> = {
  title: 'Components/Autocomplete',
  component: Autocomplete,
};
export default meta;
type Story = StoryObj<typeof Autocomplete>;

export const Default: Story = { args: { options, placeholder: 'Search users…' } };
export const WithLabel: Story = { args: { options, label: 'Assignee', placeholder: 'Search users…' } };
export const Required: Story = { args: { options, label: 'Owner', required: true } };
export const WithError: Story = { args: { options, label: 'Owner', error: 'Please select an owner.' } };
export const WithValue: Story = { args: { options, value: 'alice', label: 'Assignee' } };
export const Disabled: Story = { args: { options, label: 'Assignee', disabled: true } };
