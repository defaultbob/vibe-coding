import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Autocomplete } from './Autocomplete';

const options = [
  { value: 'alice', label: 'Alice Smith' },
  { value: 'bob', label: 'Bob Jones' },
  { value: 'carol', label: 'Carol White' },
];

describe('Autocomplete', () => {
  it('renders without crashing', () => {
    render(<Autocomplete options={options} />);
    expect(screen.getByRole('textbox')).toBeInTheDocument();
  });

  it('shows filtered options on focus', async () => {
    render(<Autocomplete options={options} />);
    await userEvent.click(screen.getByRole('textbox'));
    expect(screen.getByRole('listbox')).toBeInTheDocument();
    expect(screen.getAllByRole('option')).toHaveLength(3);
  });

  it('filters options by input', async () => {
    render(<Autocomplete options={options} />);
    await userEvent.type(screen.getByRole('textbox'), 'ali');
    expect(screen.getAllByRole('option')).toHaveLength(1);
    expect(screen.getByText('Alice Smith')).toBeInTheDocument();
  });

  it('calls onChange when option selected', async () => {
    const fn = jest.fn();
    render(<Autocomplete options={options} onChange={fn} />);
    await userEvent.click(screen.getByRole('textbox'));
    await userEvent.click(screen.getByText('Bob Jones'));
    expect(fn).toHaveBeenCalledWith('bob');
  });

  it('renders label', () => {
    render(<Autocomplete options={options} label="Assignee" />);
    expect(screen.getByText('Assignee')).toBeInTheDocument();
  });

  it('required shows yellow bg class', () => {
    render(<Autocomplete options={options} required />);
    expect(screen.getByRole('textbox')).toHaveClass('bg-vault-required');
  });

  it('error shows error message', () => {
    render(<Autocomplete options={options} error="Required field" />);
    expect(screen.getByText('Required field')).toBeInTheDocument();
  });

  it('disabled input cannot be interacted with', () => {
    render(<Autocomplete options={options} disabled />);
    expect(screen.getByRole('textbox')).toBeDisabled();
  });
});
