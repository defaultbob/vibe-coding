import React, { useState, useRef, useEffect, useId } from 'react';
import { cn } from '../../utils/cn';

export interface AutocompleteOption {
  value: string;
  label: string;
}

export interface AutocompleteProps {
  options: AutocompleteOption[];
  value?: string;
  onChange?: (value: string) => void;
  onInputChange?: (input: string) => void;
  placeholder?: string;
  label?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  helperText?: string;
  className?: string;
}

export const Autocomplete = React.forwardRef<HTMLInputElement, AutocompleteProps>(
  (
    {
      options,
      value,
      onChange,
      onInputChange,
      placeholder = 'Search…',
      label,
      disabled,
      required,
      error,
      helperText,
      className,
    },
    ref
  ) => {
    const id = useId();
    const [inputValue, setInputValue] = useState(
      () => options.find((o) => o.value === value)?.label ?? ''
    );
    const [open, setOpen] = useState(false);
    const [highlighted, setHighlighted] = useState(-1);
    const listRef = useRef<HTMLUListElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    const filtered = options.filter((o) =>
      o.label.toLowerCase().includes(inputValue.toLowerCase())
    );

    useEffect(() => {
      const label = options.find((o) => o.value === value)?.label ?? '';
      setInputValue(label);
    }, [value, options]);

    useEffect(() => {
      const handleClickOutside = (e: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
          setOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setInputValue(e.target.value);
      onInputChange?.(e.target.value);
      setOpen(true);
      setHighlighted(-1);
    };

    const handleSelect = (option: AutocompleteOption) => {
      setInputValue(option.label);
      onChange?.(option.value);
      setOpen(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (!open && e.key === 'ArrowDown') { setOpen(true); return; }
      if (e.key === 'ArrowDown') {
        setHighlighted((h) => Math.min(h + 1, filtered.length - 1));
      } else if (e.key === 'ArrowUp') {
        setHighlighted((h) => Math.max(h - 1, 0));
      } else if (e.key === 'Enter' && highlighted >= 0) {
        handleSelect(filtered[highlighted]);
      } else if (e.key === 'Escape') {
        setOpen(false);
      }
    };

    return (
      <div ref={containerRef} className={cn('relative', className)}>
        {label && (
          <label htmlFor={id} className="block text-xs font-bold text-vault-ink mb-0.5">
            {label}
            {required && <span className="text-vault-danger ml-0.5">*</span>}
          </label>
        )}
        <div className="relative">
          <input
            ref={ref}
            id={id}
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            onFocus={() => setOpen(true)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            disabled={disabled}
            required={required}
            aria-expanded={open}
            aria-autocomplete="list"
            aria-haspopup="listbox"
            className={cn(
              'w-full h-7 rounded-[2px] border text-sm px-2 pr-7 focus:outline-none focus:border-vault-primary transition-colors',
              required
                ? 'bg-vault-required border-vault-primary'
                : error
                ? 'bg-red-50 border-vault-danger'
                : 'bg-vault-bg border-vault-border',
              disabled && 'bg-vault-bg-alt opacity-60 cursor-not-allowed'
            )}
          />
          <button
            type="button"
            tabIndex={-1}
            onClick={() => setOpen((o) => !o)}
            disabled={disabled}
            className="absolute right-1.5 top-1/2 -translate-y-1/2 text-vault-muted hover:text-vault-ink"
            aria-label="Toggle dropdown"
          >
            <i className={cn('fa-solid fa-chevron-down text-xs transition-transform', open && 'rotate-180')} />
          </button>
        </div>
        {open && filtered.length > 0 && (
          <ul
            ref={listRef}
            role="listbox"
            className="absolute z-50 w-full mt-0.5 bg-vault-bg border border-vault-border rounded-[2px] shadow-dropdown max-h-48 overflow-y-auto"
          >
            {filtered.map((option, i) => (
              <li
                key={option.value}
                role="option"
                aria-selected={option.value === value}
                onClick={() => handleSelect(option)}
                className={cn(
                  'px-2.5 py-1.5 text-sm cursor-pointer',
                  i === highlighted ? 'bg-vault-bg-row-hover' : 'hover:bg-vault-bg-row-hover',
                  option.value === value && 'font-bold text-vault-primary'
                )}
              >
                {option.label}
              </li>
            ))}
          </ul>
        )}
        {error && <p className="text-label text-vault-danger mt-0.5">{error}</p>}
        {helperText && !error && <p className="text-label text-vault-muted mt-0.5">{helperText}</p>}
      </div>
    );
  }
);

Autocomplete.displayName = 'Autocomplete';
