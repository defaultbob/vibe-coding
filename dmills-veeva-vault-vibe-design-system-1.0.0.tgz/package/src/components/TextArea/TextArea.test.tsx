import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TextArea } from './TextArea';

describe('TextArea', () => {
  it('renders without crashing', () => {
    render(<TextArea />);
    expect(screen.getByRole('textbox')).toBeInTheDocument();
  });

  it('renders label', () => {
    render(<TextArea label="Notes" />);
    expect(screen.getByText('Notes')).toBeInTheDocument();
  });

  it('required prop applies yellow bg', () => {
    render(<TextArea required />);
    expect(screen.getByRole('textbox')).toHaveClass('bg-vault-required');
  });

  it('error shows error message', () => {
    render(<TextArea error="This field is required" />);
    expect(screen.getByText('This field is required')).toBeInTheDocument();
  });

  it('error applies danger border', () => {
    render(<TextArea error="Error" />);
    expect(screen.getByRole('textbox')).toHaveClass('border-vault-danger');
  });

  it('helperText shown when no error', () => {
    render(<TextArea helperText="Max 500 characters" />);
    expect(screen.getByText('Max 500 characters')).toBeInTheDocument();
  });

  it('disabled textarea has disabled attribute', () => {
    render(<TextArea disabled />);
    expect(screen.getByRole('textbox')).toBeDisabled();
  });

  it('calls onChange when text entered', async () => {
    const fn = jest.fn();
    render(<TextArea onChange={fn} />);
    await userEvent.type(screen.getByRole('textbox'), 'Hello world');
    expect(fn).toHaveBeenCalled();
  });

  it('has min-h-[60px] class', () => {
    render(<TextArea />);
    expect(screen.getByRole('textbox')).toHaveClass('min-h-[60px]');
  });
});
