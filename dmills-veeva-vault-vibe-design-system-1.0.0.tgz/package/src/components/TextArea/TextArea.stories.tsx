import type { Meta, StoryObj } from '@storybook/react';
import { TextArea } from './TextArea';

const meta: Meta<typeof TextArea> = {
  title: 'Components/TextArea',
  component: TextArea,
};
export default meta;
type Story = StoryObj<typeof TextArea>;

export const Default: Story = { args: { label: 'Description', placeholder: 'Enter a description…' } };
export const Required: Story = { args: { label: 'Notes', required: true, placeholder: 'Required…' } };
export const WithError: Story = { args: { label: 'Comments', error: 'This field is required.', placeholder: 'Enter comments…' } };
export const WithHelperText: Story = { args: { label: 'Rejection Reason', helperText: 'Explain why the document was rejected. Max 500 characters.', rows: 4 } };
export const Disabled: Story = { args: { label: 'Read-only Notes', disabled: true, value: 'This document was reviewed by the quality team.' } };
