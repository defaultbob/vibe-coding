import React, { useId } from 'react';
import { cn } from '../../utils/cn';

export interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  helperText?: string;
  error?: string;
}

export const TextArea = React.forwardRef<HTMLTextAreaElement, TextAreaProps>(
  ({ label, helperText, error, required, disabled, className, id: externalId, ...props }, ref) => {
    const generatedId = useId();
    const id = externalId ?? generatedId;

    return (
      <div className="flex flex-col gap-0.5">
        {label && (
          <label htmlFor={id} className="text-xs font-bold text-vault-ink">
            {label}
            {required && <span className="text-vault-danger ml-0.5">*</span>}
          </label>
        )}
        <textarea
          ref={ref}
          id={id}
          required={required}
          disabled={disabled}
          className={cn(
            'rounded-[2px] border text-sm px-2 py-1.5 min-h-[60px] resize-y focus:outline-none focus:border-vault-primary transition-colors',
            required
              ? 'bg-vault-required border-vault-primary'
              : error
              ? 'bg-red-50 border-vault-danger'
              : 'bg-vault-bg border-vault-border',
            disabled && 'bg-vault-bg-alt opacity-60 cursor-not-allowed resize-none',
            className
          )}
          {...props}
        />
        {error && (
          <p className="text-label text-vault-danger">{error}</p>
        )}
        {helperText && !error && (
          <p className="text-label text-vault-muted">{helperText}</p>
        )}
      </div>
    );
  }
);

TextArea.displayName = 'TextArea';
