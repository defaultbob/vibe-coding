import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Pill } from './Pill';

const meta: Meta<typeof Pill> = {
  title: 'Components/Pill',
  component: Pill,
};
export default meta;
type Story = StoryObj<typeof Pill>;

export const Default: Story = { args: { children: 'Status: Approved' } };
export const Removable: Story = { args: { children: 'Document Type: Protocol', onRemove: () => {} } };
export const Multiple: StoryObj = {
  render: () => (
    <div className="flex flex-wrap gap-1">
      <Pill onRemove={() => {}}>Status: Draft</Pill>
      <Pill onRemove={() => {}}>Owner: David Mills</Pill>
      <Pill onRemove={() => {}}>Type: Protocol</Pill>
      <Pill onRemove={() => {}}>Created: 2026</Pill>
    </div>
  ),
};
