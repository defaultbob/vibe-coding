import React from 'react';
import { cn } from '../../utils/cn';

export interface PillProps {
  children: React.ReactNode;
  onRemove?: () => void;
  className?: string;
}

export const Pill: React.FC<PillProps> = ({ children, onRemove, className }) => {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 px-2 py-0.5 rounded-[2px] text-xs leading-none',
        'bg-vault-blue-lighter border border-vault-blue-light text-vault-blue-darker',
        className
      )}
    >
      <span>{children}</span>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          aria-label={`Remove ${children}`}
          className="flex items-center justify-center w-3 h-3 rounded-full hover:bg-vault-blue-light text-vault-blue-darker leading-none ml-0.5 flex-shrink-0"
        >
          ×
        </button>
      )}
    </span>
  );
};

Pill.displayName = 'Pill';
