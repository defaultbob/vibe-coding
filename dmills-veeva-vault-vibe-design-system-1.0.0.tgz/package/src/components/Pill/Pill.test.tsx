import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Pill } from './Pill';

describe('Pill', () => {
  it('renders children', () => {
    render(<Pill>Status: Active</Pill>);
    expect(screen.getByText('Status: Active')).toBeInTheDocument();
  });

  it('applies blue tint styles', () => {
    const { container } = render(<Pill>Filter</Pill>);
    expect(container.firstChild).toHaveClass('bg-vault-blue-lighter');
    expect(container.firstChild).toHaveClass('border-vault-blue-light');
  });

  it('renders remove button when onRemove provided', () => {
    render(<Pill onRemove={() => {}}>Tag</Pill>);
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('calls onRemove when × clicked', async () => {
    const fn = jest.fn();
    render(<Pill onRemove={fn}>Status: Active</Pill>);
    await userEvent.click(screen.getByRole('button'));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('no remove button when onRemove not provided', () => {
    render(<Pill>Read-only</Pill>);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });
});
