import { render, screen } from '@testing-library/react';
import { Badge } from './Badge';

describe('Badge', () => {
  it('renders children', () => {
    render(<Badge tone="blue">Active</Badge>);
    expect(screen.getByText('Active')).toBeInTheDocument();
  });

  it('applies blue tone classes', () => {
    render(<Badge tone="blue">Active</Badge>);
    expect(screen.getByText('Active')).toHaveClass('bg-vault-primary');
  });

  it('applies greenlt tone classes', () => {
    render(<Badge tone="greenlt">Approved</Badge>);
    expect(screen.getByText('Approved')).toHaveClass('bg-vault-green-lightest');
  });

  it('applies red tone classes', () => {
    render(<Badge tone="red">Error</Badge>);
    expect(screen.getByText('Error')).toHaveClass('bg-vault-danger');
  });

  it('defaults to gray tone', () => {
    render(<Badge>Default</Badge>);
    expect(screen.getByText('Default')).toHaveClass('bg-vault-gray-darker');
  });

  it('applies uppercase tracking classes', () => {
    render(<Badge tone="blue">Label</Badge>);
    expect(screen.getByText('Label')).toHaveClass('uppercase', 'tracking-wider');
  });
});
