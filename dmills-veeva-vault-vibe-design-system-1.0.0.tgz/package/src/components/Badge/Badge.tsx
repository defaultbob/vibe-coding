import React from 'react';
import { cn } from '../../utils/cn';

export type BadgeTone =
  | 'blue'
  | 'bluelt'
  | 'green'
  | 'greenlt'
  | 'red'
  | 'yellow'
  | 'orange'
  | 'gray'
  | 'graylt';

export interface BadgeProps {
  tone?: BadgeTone;
  children: React.ReactNode;
  className?: string;
}

const toneStyles: Record<BadgeTone, string> = {
  blue: 'bg-vault-primary text-white',
  bluelt: 'bg-vault-blue-lighter text-vault-blue-darker',
  green: 'bg-vault-success text-white',
  greenlt: 'bg-vault-green-lightest text-vault-green-darker',
  red: 'bg-vault-danger text-white',
  yellow: 'bg-vault-yellow text-vault-black',
  orange: 'bg-vault-accent text-white',
  gray: 'bg-vault-gray-darker text-white',
  graylt: 'bg-vault-gray-light text-vault-muted',
};

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ tone = 'gray', children, className }, ref) => {
    return (
      <span
        ref={ref}
        className={cn(
          'inline-block px-2 py-0.5 text-label font-bold uppercase tracking-wider rounded-[2px]',
          toneStyles[tone],
          className
        )}
      >
        {children}
      </span>
    );
  }
);

Badge.displayName = 'Badge';
