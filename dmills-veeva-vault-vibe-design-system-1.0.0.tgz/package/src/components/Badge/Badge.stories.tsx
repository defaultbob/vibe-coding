import type { Meta, StoryObj } from '@storybook/react';
import { Badge } from './Badge';

const meta: Meta<typeof Badge> = {
  title: 'Components/Badge',
  component: Badge,
};
export default meta;
type Story = StoryObj<typeof Badge>;

export const Blue: Story = { args: { tone: 'blue', children: 'Active' } };
export const BlueLt: Story = { args: { tone: 'bluelt', children: 'Draft' } };
export const Green: Story = { args: { tone: 'green', children: 'Approved' } };
export const GreenLt: Story = { args: { tone: 'greenlt', children: 'Steady State' } };
export const Red: Story = { args: { tone: 'red', children: 'Rejected' } };
export const Yellow: Story = { args: { tone: 'yellow', children: 'Pending' } };
export const Orange: Story = { args: { tone: 'orange', children: 'In Review' } };
export const Gray: Story = { args: { tone: 'gray', children: 'Obsolete' } };
export const GrayLt: Story = { args: { tone: 'graylt', children: 'Inactive' } };
